package Vista;

import Controlador.ControladorAjedrez;
import Controlador.Posicion;
import Modelo.ModeloTableroAjedrez;
import Modelo.validadorMoviminetoAjedrez;
import Modelo.piezaAjedrez;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * La clase ChessBoardView es responsable de representar el tablero de ajedrez y de gestionar las interacciones del usuario.
 * Utiliza las clases ChessBoardModel y ChessMoveValidator para gestionar el estado del juego y validar los movimientos.
 */

public class VisorTableroAjedrez extends JPanel {
    private static final int TAMAÑO_CUADRO = 60;
    private static final Color CUADRO_CLARO = new Color(240, 217, 181);
    private static final Color CUADRO_OSCURO = new Color(181, 136, 99);
    private static final Color CUADRO_SELECCIONADO = new Color(186, 202, 68);

    private ModeloTableroAjedrez modelo;
    private validadorMoviminetoAjedrez validadorMovimiento;
    private Posicion posicionSeleccionada;
    private JLabel etiquetaEstatus;
    private boolean debugMode = false;
    private JLabel etiquetaContadorTurno;
    private ControladorAjedrez controlador;

    /**
     * Construye un objeto VisorTableroAjedrez con el ModeloTableroAjedrez dado.
     * Inicializa los componentes de la interfaz de usuario y configura los detectores de eventos.
     *
     * @param modelo el modelo que utilizará la vista
     */

    public VisorTableroAjedrez(ModeloTableroAjedrez modelo) {
        this.modelo = modelo;
        this.validadorMovimiento = new validadorMoviminetoAjedrez(modelo);
        setPreferredSize(new Dimension(8 * TAMAÑO_CUADRO, 8 * TAMAÑO_CUADRO));

        JPanel statusPanel = new JPanel(new GridLayout(2, 1));
        etiquetaEstatus = new JLabel("Turno blanco");
        etiquetaEstatus.setHorizontalAlignment(SwingConstants.CENTER);
        etiquetaContadorTurno = new JLabel("Turno: 1");
        etiquetaContadorTurno.setHorizontalAlignment(SwingConstants.CENTER);

        statusPanel.add(etiquetaContadorTurno);
        statusPanel.add(etiquetaEstatus);

        setLayout(new BorderLayout());
        add(statusPanel, BorderLayout.SOUTH);

        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                handleMouseClick(e);
            }
        });
    }

    /**
     * Maneja los eventos de clic del mouse en el tablero de ajedrez.
     * Determina la posición en la que se hizo clic y realiza las acciones correspondientes, como seleccionar una pieza o realizar un movimiento.
     *
     * @param e el MouseEvent que representa el clic del mouse
     */


    public void handleMouseClick(MouseEvent e) {
        int col = e.getX() / TAMAÑO_CUADRO;
        int row = e.getY() / TAMAÑO_CUADRO;
        Posicion clickedPos = new Posicion(row, col);
        String turnoActual = validadorMovimiento.getTurnoActual().toLowerCase();

        if (posicionSeleccionada != null) {

            // Si hay  una pieza seleccionada

            if (validadorMovimiento.MovimientoValidos(posicionSeleccionada, clickedPos)) {
                // Si hace clic en una posición de movimiento válida, realice el movimiento

                controlador.handleMovimiento(posicionSeleccionada, clickedPos);
                limpiarSeleccion();
            } else {
                // Si hace clic en otra posición
                piezaAjedrez piezaclickeada = modelo.getPieza(clickedPos);
                if (piezaclickeada != null && piezaclickeada.getColor().toLowerCase().equals(turnoActual)) {
                    // Si hace clic en su propia pieza, selecciónela en su lugar

                    posicionSeleccionada = clickedPos;
                } else {
                    // Si hace clic en una posición no válida, borre la selección

                    limpiarSeleccion();
                }
            }
        } else {
            //No hay ninguna pieza seleccionada todavía

            piezaAjedrez pieza = modelo.getPieza(clickedPos);
            if (pieza != null && pieza.getColor().toLowerCase().equals(turnoActual)) {
                posicionSeleccionada = clickedPos;
            }
        }
        repaint();
    }




    /**
     * Borra la posición seleccionada actualmente.
     */

    private void limpiarSeleccion() {
        posicionSeleccionada = null;
    }

    /**
     * Establece el ControladorAjedrez para VisorTableroAjedrez.
     *
     * @param controlador el ControladorAjedrez que se utilizará
     */

    public void setControlador(ControladorAjedrez controlador) {
        this.controlador = controlador;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        dibujarTabla(g);

        if (posicionSeleccionada != null) {
            resaltarCuadro(g, posicionSeleccionada, CUADRO_SELECCIONADO);
        }

        dibujarPiezas(g);
        if (debugMode) {
            dibujarDebugGrid(g);
        }
    }

    /**
     * Establece la casilla seleccionada en el tablero de ajedrez.
     *
     * @param pos La posición de la casilla seleccionada
     */



    public void setCuadroSeleccionado(Posicion pos) {
        this.posicionSeleccionada = pos;
        repaint();
    }

    /**
     * Establece el mensaje de estado que se muestra en la parte inferior del tablero de ajedrez.
     *
     * @param mensaje el mensaje de estado que se mostrará
     */

    public void setMensajeEstatus(String mensaje) {
        if (etiquetaEstatus != null) {
            etiquetaEstatus.setText(mensaje);
        }
    }

    /**
     *este método se llame cuando el usuario selecciona una casilla en el tablero de
     * ajedrez o cuando se resalta un movimiento, lo que permite al usuario identificar fácilmente
     * la casilla seleccionada o resaltada en la representación visual del tablero de ajedrez.
     * @param g el objeto Graphics utilizado para dibujar en el tablero de ajedrez.
     * @param pos el objeto Position que representa el cuadrado que se va a resaltar.
     * @param color el color que se utilizará para resaltar el cuadrado.
     */

    private void resaltarCuadro(Graphics g, Posicion pos, Color color) {
        g.setColor(color);
        g.fillRect(pos.getCol() * TAMAÑO_CUADRO, pos.getFila() * TAMAÑO_CUADRO, TAMAÑO_CUADRO, TAMAÑO_CUADRO);
    }

    /**
     * Actualiza el contador de turnos que se muestra en la parte inferior del tablero de ajedrez.
     *
     * @param turno el número de turno actual
     */

    public void actualizarContadorTurno(int turno) {
        if (etiquetaContadorTurno != null) {
            etiquetaContadorTurno.setText("Turno: " + turno);
        }
    }

    /**
     * Dibuja la cuadrícula del tablero de ajedrez alternando cuadrados claros y oscuros.
     *
     * @param g el objeto Graphics utilizado para dibujar en el tablero de ajedrez.
     */


    private void dibujarTabla(Graphics g) {
        for (int fila = 0; fila < 8; fila++) {
            for (int col = 0; col < 8; col++) {
                boolean isLight = (fila + col) % 2 == 0;
                g.setColor(isLight ? CUADRO_CLARO : CUADRO_OSCURO);
                g.fillRect(col * TAMAÑO_CUADRO, fila * TAMAÑO_CUADRO, TAMAÑO_CUADRO, TAMAÑO_CUADRO);
            }
        }
    }

    /**
     * Dibuja las piezas de ajedrez en el tablero utilizando una fuente adecuada.
     *
     * @param g el objeto Graphics utilizado para dibujar en el tablero de ajedrez.
     */


    private void dibujarPiezas(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        // Crear un array de fuentes que soporten símbolos Unicode de ajedrez

        Font[] fuente = {
                new Font("DejaVu Sans", Font.PLAIN, 48),
                new Font("Arial Unicode MS", Font.PLAIN, 48),
                new Font("Segoe UI Symbol", Font.PLAIN, 48),
                new Font("Arial", Font.BOLD, 48)
        };

        // Encuentra la 1° fuente disponible
        Font fuenteAjedrez = null;
        for (Font font : fuente) {
            if (font.canDisplay('♔')) {
                fuenteAjedrez = font;
                break;
            }
        }

        if (fuenteAjedrez == null) {
            System.err.println("Warning: Fuente no encontrada");
            fuenteAjedrez = fuente[fuente.length - 1]; // Use last font as fallback
        }

        g2d.setFont(fuenteAjedrez);
        System.out.println("Usando fuente: " + fuenteAjedrez.getFontName());

        for (int fila = 0; fila < 8; fila++) {
            for (int col = 0; col < 8; col++) {
                Posicion pos = new Posicion(fila, col);
                piezaAjedrez pieza = modelo.getPieza(pos);
                if (pieza != null) {
                    // Debug
                    if (debugMode) {
                        System.out.printf("Drawing piece at (%d,%d): %s%n",
                                fila, col, pieza.toString());
                    }

                    String simbolo = String.valueOf(pieza.getSimbolo());
                    FontMetrics fm = g2d.getFontMetrics();
                    int x = col * TAMAÑO_CUADRO + (TAMAÑO_CUADRO - fm.stringWidth(simbolo)) / 2;
                    int y = fila * TAMAÑO_CUADRO + ((TAMAÑO_CUADRO + fm.getHeight()) / 2) - fm.getDescent();

                    if (pieza.getColor().equals("white")) {
                        // Piezas blancas
                        g2d.setColor(Color.BLACK);
                        g2d.drawString(simbolo, x + 1, y + 1);
                        g2d.setColor(Color.WHITE);
                    } else {
                        // Piezas negras
                        g2d.setColor(Color.WHITE);
                        g2d.drawString(simbolo, x + 1, y + 1);
                        g2d.setColor(Color.BLACK);
                    }
                    g2d.drawString(simbolo, x, y);
                }
            }
        }
    }

    /**
     * Muestra el cuadro de diálogo de fin del juego y solicita al usuario que guarde el juego.
     *
     * @param ganador el ganador del juego (ya sea "Blanco" o "Negro")
     */


    public void juegoTerminado(String ganador) {
        int elegir = JOptionPane.showConfirmDialog(
                this,
                ganador + " - Quieres guardar el juego?",
                "Juego terminado",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.INFORMATION_MESSAGE
        );

        if (elegir == JOptionPane.YES_OPTION) {
            if (controlador != null) {
                controlador.handleGuardarJuego();
            }
        }
    }

    /**
     * Muestra un diálogo para que el jugador elija la pieza que va a promocionar como peón.
     *
     * @param color el color del peón que va a promocionar ("blanco" o "negro")
     * @return la pieza elegida para promocionar (ya sea "reina", "torre", "alfil" o "caballo")
     */


    public String showDialogoCoronacion(String color) {
        Object[] opciones = {"Dama", "Torre", "Alfil", "Caballo"};
        String titulo = color.substring(0, 1).toUpperCase() + color.substring(1) + " Coronacion Peon";

        int elegir = JOptionPane.showOptionDialog(this,
                "Elige la pieza:",
                titulo,
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                opciones,
                opciones[0]);

        if (elegir >= 0) {
            return opciones[elegir].toString().toLowerCase();
        }

        return "queen"; // Por defecto es reina si el diálogo es cerrado

    }

    /**
     * Dibuja una cuadrícula de depuración en el tablero de ajedrez, incluidas las etiquetas de filas y columnas.
     *
     * @param g el objeto Graphics utilizado para dibujar en el tablero de ajedrez.
     */


    private void dibujarDebugGrid(Graphics g) {
        g.setColor(Color.RED);
        for (int i = 0; i <= 8; i++) {
            g.drawLine(i * TAMAÑO_CUADRO, 0, i * TAMAÑO_CUADRO, 8 * TAMAÑO_CUADRO);
            g.drawLine(0, i * TAMAÑO_CUADRO, 8 * TAMAÑO_CUADRO, i * TAMAÑO_CUADRO);
        }
        g.setFont(new Font("Arial", Font.PLAIN, 10));
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                g.drawString(String.format("(%d,%d)", i, j),
                        j * TAMAÑO_CUADRO + 2,
                        i * TAMAÑO_CUADRO + 12);
            }
        }
    }
}