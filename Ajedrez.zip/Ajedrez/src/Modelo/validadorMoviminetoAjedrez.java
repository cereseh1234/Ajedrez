package Modelo;

import Controlador.Posicion;

public class validadorMoviminetoAjedrez {
    private ModeloTableroAjedrez tablero;
    private int turnoContador;  // Realiza un seguimiento del turno actual



    public validadorMoviminetoAjedrez(ModeloTableroAjedrez tablero) {
        this.tablero = tablero;
        this.turnoContador = 1;// Comienza con el turno 1 (Blanco)
    }

    public boolean MovimientoValidos(Posicion from, Posicion to) {
        piezaAjedrez pieza = tablero.getPieza(from);
        if (pieza == null) return false;// Si no hay ninguna pieza en la posición 'from', el movimiento no es válido




        // Convierte colores a minúsculas para comparar

        String turnoActual = getTurnoActual();
        String piezaColor = pieza.getColor().toLowerCase();

        if (!piezaColor.equals(turnoActual)) {
            System.out.println("Turno equivocado! Turno actual: " + turnoActual + ", Color Pieza: " + piezaColor);
            return false;
        }

        // No puedes capturar tu propia pieza

        piezaAjedrez targetPieza = tablero.getPieza(to);
        if (targetPieza != null && targetPieza.getColor().toLowerCase().equals(piezaColor)) {
            return false;
        }

        String tipoPieza = pieza.getTipo().toLowerCase();
        boolean movimientoValidoPieza = switch (tipoPieza) {
            case "pawn" -> movimientoValidoPeon(from, to, piezaColor);
            case "rook" -> movimientoTorreValido(from, to);
            case "knight" -> movimientoCaballoValido(from, to);
            case "bishop" -> movimientoValidoAlfil(from, to);
            case "queen" -> movimientoValidoDama(from, to);
            case "king" -> movimientoValidoRey(from, to);
            default -> false;
        };

        return movimientoValidoPieza;
    }

    /**
     * Método para obtener el turno actual en función del contador de turnos
     *
     * @return el color de jugador apropiado en función del resultado de la condición.
     * Si la condición es verdadera, el método devuelve "blanco".
     * De lo contrario, devuelve "negro".
     */

    public String getTurnoActual() {
        //La expresión turnoContador % 2 == 1 verifica si el contador de turnos actual
// es un número impar. Esto se debe a que queremos asignar al jugador "blanco"
// los turnos impares y al jugador "negro" los turnos pares.

        return (turnoContador % 2 == 1) ? "white" : "black";
    }
    /**
     * // Método para cambiar de turno
     */

    public void cambiarTurno() {
        turnoContador++;
        System.out.println("Turn " + turnoContador + ": " + getTurnoActual() + " turno");
    }

    /** * Getter para el contador de turnos *
     * * @return devuelve el valor actual de la variable Contador de turnos. */

    public int getContadorTurno() {
        return turnoContador;
    }


    /**
     * jakeMate es responsable
     * de determinar si el jugador actual se encuentra en una situación de jaque mate
     *
     * @return Regresa true si no se encuentran movimientos válidos para sacar al rey del jaque, lo que indica un jaque mate.
     */


    public boolean jakeMate() {
        //El método primero obtiene el turno del jugador actual
        String jugadorActual = getTurnoActual();

        // Primero verifique que el jugador actual esté realmente en control

        if (!enJake(jugadorActual)) {
            return false;
        }

        // Intenta todos los movimientos posibles para todas las piezas del jugador actual

        for (int fromFila = 0; fromFila < 8; fromFila++) {
            for (int fromCol = 0; fromCol < 8; fromCol++) {
                Posicion from = new Posicion(fromFila, fromCol);
                piezaAjedrez pieza = tablero.getPieza(from);

                // Omitir si no es la pieza del jugador actual

                if (pieza == null || !pieza.getColor().equalsIgnoreCase(jugadorActual)) {
                    continue;
                }

                //Recorre todas las casillas del tablero de ajedrez, comprobando en cada casilla si hay una pieza que pertenece al jugador actual.
                for (int toFila = 0; toFila < 8; toFila++) {
                    for (int toCol = 0; toCol < 8; toCol++) {
                        Posicion to = new Posicion(toFila, toCol);

                        // Omite si no es la pieza del jugador actual

                        if (!MovimientoValidos(from, to)) {
                            continue;
                        }

                        piezaAjedrez piezaCapturada = tablero.getPieza(to);

                        tablero.moverPieza(from, to);

                        // Comprueba si todavía esta en control

                        boolean todaviaEnJake = enJake(jugadorActual);

                        // Deshace el movimiento

                        tablero.moverPieza(to, from);
                        if (piezaCapturada != null) {
                            tablero.lugarPieza(to, piezaCapturada);
                        }

                        // Si este movimiento lo saca del jaque, no es jaque mate.

                        if (!todaviaEnJake) {
                            return false;
                        }
                    }
                }
            }
        }

        //no se encontraron movimientos legales para salir del control.

        return true;
    }

    /**
     *cuadroAtacado es responsable de determinar si una casilla determinada del tablero
     *  de ajedrez está bajo ataque por alguna de las piezas del oponente.
     * @param cuadro La posición en el tablero que queremos comprobar en busca de ataques.
     * @param colorAtacante El color del jugador cuyas piezas queremos comprobar para detectar ataques.
     * @return //Si el método completa el bucle sin encontrar ninguna de las colorPiezaAtacante del jugador que pueda atacar al cuadro, devuelve false, lo que indica que el cuadro no está bajo ataque.
     */
    private boolean cuadroAtacado(Posicion cuadro, String colorAtacante) {
        //El método itera a través de todos los cuadrados del tablero de ajedrez (cuadrícula de 8x8).
        //Para cada cuadrado, verifica si hay una pieza en ese cuadrado y si la pieza pertenece al jugadorcolorAtacante.
        //Si se encuentra una pieza que pertenece al jugadorColorAtacnate, el método llama al  puedePuezaAtacarXCuadro()método para verificar si esa pieza puede atacar al squareque se pasó como parámetro.
        //Si el  puedePuezaAtacarXCuadro()método devuelve true, el cuadroAtacado()método devuelve inmediatamente true, lo que indica que el cuadrado está bajo ataque.

        for (int fila = 0; fila < 8; fila++) {
            for (int col = 0; col < 8; col++) {
                Posicion from = new Posicion(fila, col);
                piezaAjedrez pieza = tablero.getPieza(from);

                if (pieza != null &&
                        pieza.getColor().equalsIgnoreCase(colorAtacante) &&
                        puedePuezaAtacarXCuadro(from, cuadro, pieza)) {
                    return true;
                }
            }
        }
        return false;
    }

     /**
     * movimientoDeberiaPrevenirJake se utiliza para determinar si un movimiento propuesto evitaría
     * que el rey del jugador quede en jaque.
     *
     * @param from La posición en el tablero donde se encuentra actualmente la pieza.
     * @param to  La posición en el tablero donde se propone mover la pieza.
     * @param colorJugador El color del jugador cuyo movimiento se está evaluando.
     * @return
     */

    private boolean movimientoDeberiaPrevenirJake(Posicion from, Posicion to, String colorJugador) {
        // Guarda el estado actual del tablero


        piezaAjedrez piezaCapturada = tablero.getPieza(to);

        // Hace el movimiento temporalmente

        tablero.moverPieza(from, to);

        // Comprueba si el rey todavía está en jaque

        boolean todaviaEnJake = enJake(colorJugador);

        // Restaurar el estado del tablero

        tablero.moverPieza(to, from);
        if (piezaCapturada != null) {
            tablero.lugarPieza(to, piezaCapturada);
        }

        // Devuelve verdadero si este movimiento evitaría la verificación

        return !todaviaEnJake;
    }

    /**
     * enJake es responsable de determinar si el rey de un jugador en particular está en jaque.
     * @param colorJugador Color del jugador
     * @return Si el cuadroAtacado()método devuelve false, el enJake()
     * método devuelve false, lo que indica que el rey del jugador no está en jaque
     */

    public boolean enJake(String colorJugador) {
        Posicion posicionRey = encontrarRey(colorJugador);
        if (posicionRey == null) return false;

        String colorOponente = colorJugador.equalsIgnoreCase("white") ? "black" : "white";
        return cuadroAtacado(posicionRey, colorOponente);
    }
    /**
     * determinar si una pieza determinada puede atacar una casilla específica del tablero de ajedrez, independientemente del turno del jugador actual. Esto es útil para comprobar si un rey está en jaque,
     * ya que el método debe tener en cuenta todas las piezas del oponente que podrían atacar la casilla del rey.
     * puede atacar el cuadrado especificado por el parámetro 'to', comenzando desde la posición 'from'.
     *
     *@param from La posición en el tablero donde se encuentra actualmente la pieza.
      * @param to  La posición en el tablero donde se propone mover la pieza.
     * @param pieza  La pieza que quiere atacar
     * @return
     */


    private boolean puedePuezaAtacarXCuadro(Posicion from, Posicion to, piezaAjedrez pieza) {
        String tipoPieza = pieza.getTipo().toLowerCase();

        // Utilice la lógica de validación de movimientos existente pero ignore el orden de turno

        switch (tipoPieza) {
            case "pawn":
                return movimientoValidoPeon(from, to, pieza.getColor().toLowerCase());
            case "rook":
                return movimientoTorreValido(from, to);
            case "knight":
                return movimientoCaballoValido(from, to);
            case "bishop":
                return movimientoValidoAlfil(from, to);
            case "queen":
                return movimientoValidoDama(from, to);
            case "king":
                return movimientoValidoRey(from, to);
            default:
                return false;
        }
    }


    /**
     * Ubica la posición del rey de un color determinado en el tablero de ajedrez.
     *
     * @param color el color del rey a buscar ("blanco" o "negro").
     * @return la posición del rey si se encuentra; de lo contrario, nulo.
     */

    private Posicion encontrarRey(String color) {
        for (int fila = 0; fila < 8; fila++) {
            for (int col = 0; col < 8; col++) {
                Posicion pos = new Posicion(fila, col);
                piezaAjedrez pieza = tablero.getPieza(pos);
                if (pieza != null &&
                        pieza.getTipo().toLowerCase().equals("king") &&
                        pieza.getColor().toLowerCase().equals(color)) {
                    return pos;
                }
            }
        }
        return null;
    }

    /**
     * determina si el movimiento de un peón es válido en función de su posición actual
     *
     * @param from  La posición inicial del peón.
     * @param to    La posición objetivo a la que el peón pretende moverse.
     * @param color El color del peón (ya sea "blanco" o "negro"
     * @return Si no se cumple ninguna de las condiciones para un movimiento válido, devuelve .false
     */

    private boolean movimientoValidoPeon(Posicion from, Posicion to, String color) {
        int direccion = color.equals("white") ? -1 : 1;
        int filaDiff = to.getFila() - from.getFila();
        int colDiff = Math.abs(to.getCol() - from.getCol());

        // Movimiento básico hacia adelante

        if (colDiff == 0 && filaDiff == direccion && tablero.getPieza(to) == null) {
            return true;
        }

        // Movimiento inicial de dos cuadrados

        if (colDiff == 0 && ((color.equals("white") && from.getFila() == 6 && filaDiff == -2) ||
                (color.equals("black") && from.getFila() == 1 && filaDiff == 2))) {
            Posicion intermedia = new Posicion(from.getFila() + direccion, from.getCol());
            return tablero.getPieza(intermedia) == null && tablero.getPieza(to) == null;
        }

        // Captura

        if (colDiff == 1 && filaDiff == direccion) {
            piezaAjedrez piezaObjetivo = tablero.getPieza(to);
            return piezaObjetivo != null && !piezaObjetivo.getColor().toLowerCase().equals(color);
        }

        return false;
    }

    /**
     * valida si una torre puede moverse de una posición a otra en un tablero de ajedrez
     *
     * @param from La posición inicial de la torre.
     * @param to   :La posición objetivo a la que la torre pretende moverse.
     * @return true: Si el movimiento de la torre es válido
     * false: Si el movimiento no es válido
     */

    private boolean movimientoTorreValido(Posicion from, Posicion to) {
        if (from.getFila() != to.getFila() && from.getCol() != to.getCol()) return false;
        return !caminoBloqueado(from, to);
    }

    /**
     * valida si el caballo puede moverse de una posición a otra en un tablero de ajedrez
     *
     * @param from La posición inicial del caballo.
     * @param to   :La posición objetivo a la que el caballo pretende moverse.
     * @return true: Si el movimiento del caballo  es válido
     * false: Si el movimiento no es válido
     */


    private boolean movimientoCaballoValido(Posicion from, Posicion to) {
        int filaDiff = Math.abs(to.getFila() - from.getFila());
        int colDiff = Math.abs(to.getCol() - from.getCol());
        return (filaDiff == 2 && colDiff == 1) || (filaDiff == 1 && colDiff == 2);
    }

    /**
     * valida si el alfil puede moverse de una posición a otra en un tablero de ajedrez
     *
     * @param from La posición inicial del alfil.
     * @param to   La posición objetivo a la que el alfil pretende moverse
     * @return true: Si el movimiento del alfil  es válido
     * false: Si el movimiento no es válido
     */


    private boolean movimientoValidoAlfil(Posicion from, Posicion to) {
        if (Math.abs(to.getFila() - from.getFila()) != Math.abs(to.getCol() - from.getCol())) return false;
        return !caminoBloqueado(from, to);
    }

    /**
     * valida si la dama puede moverse de una posición a otra en un tablero de ajedrez
     *
     * @param from La posición inicial de la reina.
     * @param to   La posición objetivo a la que la reina pretende moverse
     * @return true: Si el movimiento de la  reina  es válido
     * false: Si el movimiento no es válido
     */


    private boolean movimientoValidoDama(Posicion from, Posicion to) {
        return movimientoTorreValido(from, to) || movimientoValidoAlfil(from, to);
    }

/**
 * valida si el rey puede moverse de una posición a otra en un tablero de ajedrez
 *
 * @param from La posición inicial del rey.
 * @param to  La posición objetivo a la que el rey  pretende moverse
 * @return true: Si el movimiento de la  reina  es válido
 * * false: si el movimiento no es valido
 * */
    private boolean movimientoValidoRey(Posicion from, Posicion to) {
        int filaDiff = Math.abs(to.getFila() - from.getFila());
        int colDiff = Math.abs(to.getCol() - from.getCol());
        return filaDiff <= 1 && colDiff <= 1;
    }

    /**
     * verifica si el estado actual de la partida es un empate en ajedrez
     * @return Si se han comprobado todos los movimientos posibles y no se encuentra ninguno
     * que permita al jugador realizar un movimiento legal sin poner a su rey en jaque, entonces devuelve
     * , lo que indica un punto muerto.true
     */


    public boolean isStalemate() {
        String jugadorActual = getTurnoActual();


        // Si la jugadora está bajo control, no es un punto muerto

        if (enJake(jugadorActual)) {
            return false;
        }

        // Intenta todos los movimientos posibles para todas las piezas del jugador actual

        for (int fromFila = 0; fromFila < 8; fromFila++) {
            for (int fromCol = 0; fromCol < 8; fromCol++) {
                Posicion from = new Posicion(fromFila, fromCol);
                piezaAjedrez pieza = tablero.getPieza(from);

                // Omite si no es la pieza del jugador actual
                if (pieza == null || !pieza.getColor().equalsIgnoreCase(jugadorActual)) {
                    continue;
                }

                // Prueba todos los destinos posibles

                for (int toFila = 0; toFila < 8; toFila++) {
                    for (int toCol = 0; toCol < 8; toCol++) {
                        Posicion to = new Posicion(toFila, toCol);

                        // Comprueba si el movimiento es válido y no pone/deja al rey en jaque

                        if (MovimientoValidos(from, to) && movimientoDeberiaPrevenirJake(from, to, jugadorActual)) {
                            return false;  // Encontré al menos un movimiento legal

                        }
                    }
                }
            }
        }

        // If we get here, no legal moves were found but the king is not in check
        return true;
    }
    /**
     * El fragmento de código proporcionado define un método que comprueba si el camino entre
     * dos posiciones en un tablero de ajedrez está bloqueado por otras piezas
     * @param from La posición inicial desde la que se mueve la pieza.
     * @param to La posición objetivo a la que la pieza pretende moverse.
     * @return Si el bucle se completa sin encontrar ninguna pieza que bloquee el camino, devuelve
     * , indicando que el camino está libre.false
     */




    private boolean caminoBloqueado(Posicion from, Posicion to) {
        int filaStep = Integer.compare(to.getFila(), from.getFila());
        int colStep = Integer.compare(to.getCol(), from.getCol());

        Posicion actual = new Posicion(from.getFila() + filaStep, from.getCol() + colStep);
        while (!actual.equals(to)) {
            if (tablero.getPieza(actual) != null) return true;
            actual = new Posicion(actual.getFila() + filaStep, actual.getCol() + colStep);
        }
        return false;
    }
}