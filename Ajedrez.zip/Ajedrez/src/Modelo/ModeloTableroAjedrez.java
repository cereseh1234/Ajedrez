package Modelo;

import Controlador.Posicion;



public interface ModeloTableroAjedrez {
    void lugarPieza(Posicion pos, piezaAjedrez pieza);
    piezaAjedrez getPieza(Posicion pos);
    void limpiar();

    // Mueve la pieza
    default boolean moverPieza(Posicion from, Posicion to) {
        piezaAjedrez pieza = getPieza(from);
        if (pieza != null) {
            // Elimina la pieza
            removerPieza(from);
            // Nueva posicion
            lugarPieza(to, pieza);
            return true;
        }
        return false;
    }
    void removerPieza(Posicion pos);
}