package Modelo;

public interface piezaAjedrez {
    char getSimbolo();
    String getColor();
    String getTipo();
}