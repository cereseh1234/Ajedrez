package Controlador;

import Modelo.BasicPiezaAjedrez;
import Modelo.ModeloTableroAjedrez;
import Modelo.piezaAjedrez;
import Modelo.validadorMoviminetoAjedrez;
import Vista.VisorTableroAjedrez;

import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Map;
import javax.swing.JFileChooser;
import java.io.File;

/**
 * Controladorajedrez es la clase responsable para controlar interacciones de usuarios, actualizar el estado del juego
 * y coordinar entre las clases ModeloTableroAjedrez y la vista.
 */


public class ControladorAjedrez {
    private ModeloTableroAjedrez modelo;
    private VisorTableroAjedrez vista;
    private validadorMoviminetoAjedrez validadorMovimiento;
    private HandlerPGNTiempoReal gestorPGN;

    /**
     * Contruye un objeto ControladorAjedrez
     *
     * @param modelo    Modelo del tablero de ajedrez
     * @param vista     Es vistaTableroAjedrez
     * @param gestorPGN El gestor PGN para grabar movimientos
     */

    public ControladorAjedrez(ModeloTableroAjedrez modelo, VisorTableroAjedrez vista, HandlerPGNTiempoReal gestorPGN) {
        if (modelo == null) throw new IllegalArgumentException("El modelo no puede ser nulo");
        if (vista == null) throw new IllegalArgumentException("La vista no puede ser nula");

        this.modelo = modelo;
        this.vista = vista;
        this.gestorPGN = gestorPGN;
        this.validadorMovimiento = new validadorMoviminetoAjedrez(this.modelo);
        this.vista.setControlador(this);

        setupPosicionInicial();
        actualizarEstatusJuego();
        vista.addMouseListener(new MouseAdapter() {
            private Posicion posicionSeleccionada = null;

            @Override
            public void mouseClicked(MouseEvent e) {
                int tamañoCuadrado = 60;
                int col = e.getX() / tamañoCuadrado;
                int row = e.getY() / tamañoCuadrado;
                Posicion posicionClikeada = new Posicion(row, col);

                if (posicionSeleccionada == null) {
                    // 1° Click- Selecciona pieza
                    piezaAjedrez pieza = modelo.getPieza(posicionClikeada);
                    if (pieza != null && pieza.getColor().equals(validadorMovimiento.getTurnoActual())) {
                        posicionSeleccionada = posicionClikeada;
                        vista.setCuadroSeleccionado(posicionClikeada);
                    }
                } else {
                    // Segundo Click-Intento de Movimiento
                    if (validadorMovimiento.MovimientoValidos(posicionSeleccionada, posicionClikeada)) {
                        // Obtiene informacion de la pieza antes del movimiento
                        piezaAjedrez pieza = modelo.getPieza(posicionSeleccionada); //Cambio
                        boolean capturada = modelo.getPieza(posicionClikeada) != null; //Cambio
                        // Hace el movimiento
                        modelo.moverPieza(posicionSeleccionada, posicionClikeada);

                        //Graba movimiento en PGN
                        String fromCuadrado = posicionToAlgebra(posicionSeleccionada);
                        String toCuadrado = posicionToAlgebra(posicionClikeada);
                        String notacionPieza = getPGNPPiezaPosicion(pieza);

                        // Graba el movimiento
                        gestorPGN.gabarMovimiento(fromCuadrado, toCuadrado, notacionPieza, capturada);

                        // Cambio de turno

                        validadorMovimiento.cambiarTurno();

                         // Revisa  jakemate
                        if (validadorMovimiento.jakeMate()) {
                            String ganador = validadorMovimiento.getTurnoActual().equals("white") ? "Black" : "White";
                            String resultado = ganador.equals("White") ? "1-0" : "0-1";
                            gestorPGN.finJuego(resultado);
                            SwingUtilities.invokeLater(() -> {
                                vista.juegoTerminado(ganador);
                            });
                        }
                       // Checkeo empate o ahogo
                        else if (validadorMovimiento.isStalemate()) {
                            gestorPGN.finJuego("1/2-1/2");
                            SwingUtilities.invokeLater(() -> {
                                vista.juegoTerminado("Draw by stalemate");
                            });
                        }
                        actualizarEstatusJuego();
                    }
                    posicionSeleccionada = null;
                    vista.setCuadroSeleccionado(null);
                }

                // Refresca la vista
                vista.repaint();
            }
        });
    }

    /**
     * Actualiza el estatus del juego en la vista, Incluyendo el contador de turnos y el turno
     */
    private void actualizarEstatusJuego() {
        String jugadorActual = validadorMovimiento.getTurnoActual();
        vista.setMensajeEstatus(jugadorActual.substring(0, 1).toUpperCase() +
                jugadorActual.substring(1) + " turno" );
        vista.actualizarContadorTurno(validadorMovimiento.getContadorTurno());
    }


    /**
     * Coloca una pieza de ajedrez en el tablero en la posicion especificada
     * Convierte la notacion algebraica (por ejemplo"e4")en indices de matriz y crea la pieza adecuada.
     *
     * @param tipoPieza El tipo de pieza
     * @param color     El color de la pieza
     * @param posicion  La posicion en notacion algebraica
     */

    public void lugarPieza(String tipoPieza, String color, String posicion) {
        try {
            if (posicion == null || posicion.length() != 2) {
                throw new IllegalArgumentException("Posición inválida: " + posicion);
            }

            // Converte de notación algebraica a índices de matriz

            int col = posicion.charAt(0) - 'a';
            int fila = 8 - (posicion.charAt(1) - '0');

            if (fila >= 0 && fila < 8 && col >= 0 && col < 8) {


                Posicion pos = new Posicion(fila, col);
                piezaAjedrez pieza = crearPieza(tipoPieza, color);
                if (pieza != null) {
                    modelo.lugarPieza(pos, pieza);
                    vista.repaint(); // Asegura que la vista se actualice después de cada pieza

                } else
                    System.err.println("Error: No se pudo crear la pieza " + tipoPieza);
            }
        } catch (Exception e) {
            System.err.println("Error lugar pieza posicion " + posicion + ": " + e.getMessage());
        }
    }

    /**
     * Crea un nuevo objeto `PiezaAjedrez` basado en el tipo y color de pieza especificados.
     *
     * @param tipo  el tipo de pieza de ajedrez
     * @param color el color de la pieza de ajedrez
     * @return un nuevo objeto  que representa el tipo y color de pieza especificados
     * @throws IllegalArgumentException si el tipo de pieza proporcionado no es válido
     */

    private piezaAjedrez crearPieza(String tipo, String color) {
        char simbolo = switch (tipo.toLowerCase()) {
            case "king" -> color.equals("white") ? '♔' : '♚';
            case "queen" -> color.equals("white") ? '♕' : '♛';
            case "rook" -> color.equals("white") ? '♖' : '♜';
            case "bishop" -> color.equals("white") ? '♗' : '♝';
            case "knight" -> color.equals("white") ? '♘' : '♞';
            case "pawn" -> color.equals("white") ? '♙' : '♟';
            default -> throw new IllegalArgumentException("Tipo de pieza invalida: " + tipo);
        };
        return new BasicPiezaAjedrez(simbolo, color, tipo);
    }

    /**
     * Maneja un movimiento realizado por el usuario.
     *
     * @param from la posición inicial del movimiento
     * @param to la posición de destino del movimiento
     */


    public void handleMovimiento(Posicion from, Posicion to) {
        if (validadorMovimiento.MovimientoValidos(from, to)) {
            piezaAjedrez movientoPieza = modelo.getPieza(from);

            if (movientoPieza != null &&
                    movientoPieza.getColor().equalsIgnoreCase(validadorMovimiento.getTurnoActual())) {

                // Maneja la promoción del peón o el movimiento normal

                handleCoronacionPeon(from, to);

                // Para cambiar turno

                validadorMovimiento.cambiarTurno();

                // Revision para el jakemate
                if (validadorMovimiento.jakeMate()) {
                    // El ganador es el jugador que acaba de moverse (en el turno opuesto al actual)

                    String ganador = validadorMovimiento.getTurnoActual().equals("white") ? "Black" : "White";
                    SwingUtilities.invokeLater(() -> {
                        vista.juegoTerminado(ganador);
                    });
                    return;
                }

                // Revision para el jake

                if (validadorMovimiento.enJake(validadorMovimiento.getTurnoActual())) {
                    vista.setMensajeEstatus(validadorMovimiento.getTurnoActual().substring(0, 1).toUpperCase() +
                            validadorMovimiento.getTurnoActual().substring(1) + " is in check!");
                } else {
                    actualizarEstatusJuego();
                }
                if (validadorMovimiento.jakeMate()) {
                    // El ganador es el jugador que acaba de moverse (en el turno opuesto al actual)

                    String ganador = validadorMovimiento.getTurnoActual().equals("white") ? "Black" : "White";
                    System.out.println(ganador + " Jakemate!");
                    SwingUtilities.invokeLater(() -> {
                        vista.juegoTerminado(ganador);
                    });
                    return;
                }
            }
        }
    }

    /**
     * Maneja el proceso de guardar el juego actual en un archivo PGN.
     */

    public void handleGuardarJuego() {
        // Obtiene el turno actual para determinar el ganador

        String ganador = validadorMovimiento.getTurnoActual().equals("white") ? "Black" : "White";
        String resultado = ganador.equals("White") ? "1-0" : "0-1";

        // Actualiza el resultado del juego en el controlador PGN

        gestorPGN.finJuego(resultado);

        // Crea el selector de archivos para guardar

        JFileChooser chooserArchivo = new JFileChooser();
        chooserArchivo.setDialogTitle("Guardar PGN File");

        // Establezca el nombre de archivo predeterminado utilizando la información del juego

        String nombrePorDefectoArchivo = String.format("%s_vs_%s.pgn",
                gestorPGN.getEncabezado("White"),
                gestorPGN.getEncabezado("Black"));
        chooserArchivo.setSelectedFile(new File(nombrePorDefectoArchivo));

        // // Muestra dialogo de guardar
        int returnVal = chooserArchivo.showSaveDialog(vista);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            File archivo = chooserArchivo.getSelectedFile();
            // Añade la extension pgn si no esta presente
            if (!archivo.getName().toLowerCase().endsWith(".pgn")) {
                archivo = new File(archivo.getAbsolutePath() + ".pgn");
            }
            gestorPGN.guardarArchivoComo(archivo.getAbsolutePath());
            JOptionPane.showMessageDialog(vista,
                    "JuegoGuardadoCorrectamente: " + archivo.getName(),
                    "GuardadoCorrectamente",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }
    /**
     * Maneja la promoción de un peón que ha llegado al extremo opuesto del tablero.
     *
     * @param from la posición inicial del movimiento del peón
     * @param to la posición de destino del movimiento del peón
     */

    private void handleCoronacionPeon(Posicion from, Posicion to) {
        piezaAjedrez pieza = modelo.getPieza(from);

        // Obtene la pieza en la posición inicial

        if (pieza.getTipo().equalsIgnoreCase("pawn")) {
            int obtenerFila = to.getFila();
            boolean esPeonBlanco = pieza.getColor().equalsIgnoreCase("white");

            //Revisa si el peon alcanzo la posicion necesaria (fila 0 Blanco, fila 7 Negro)
            if ((esPeonBlanco && obtenerFila == 0) || (!esPeonBlanco && obtenerFila == 7)) {
                String elegirCoronacion = vista.showDialogoCoronacion(pieza.getColor());
                if (elegirCoronacion != null) {
                    // Registra los detalles básicos del movimiento

                    boolean capturada = modelo.getPieza(to) != null;
                    String fromCuadrado = posicionToAlgebra(from);
                    String toCuadro = posicionToAlgebra(to);

                    //Retira el peón de su posición original

                    modelo.removerPieza(from);

                    //Retira cualquier pieza capturada en el destino

                    if (capturada) {
                        modelo.removerPieza(to);
                    }

                    //Crear y colocar la nueva pieza promocionada

                    piezaAjedrez piezaCoronada = crearPieza(elegirCoronacion, pieza.getColor());
                    modelo.lugarPieza(to, piezaCoronada);

                    //Graba el movimiento con información de la promoción

                    gestorPGN.gabarMovimiento(fromCuadrado, toCuadro, "P", capturada);
                    String notacionCoronation = "=" + getPGNPPiezaPosicion(piezaCoronada);
                    gestorPGN.appendUltimoMovimiento(notacionCoronation);
                }
                return;
            }
        }
        // Si no es una coronacion del peón, simplemente mueve la pieza

        modelo.moverPieza(from, to);
    }

    /**
     * Obtiene la notación PGN (Notación de juego portátil) para la pieza de ajedrez dada.
     *
     * @param pieza la pieza de ajedrez para la que se obtendrá la notación
     * @return la notación PGN para la pieza dada, o "P" (peón) si la pieza es nula
     */

    private String getPGNPPiezaPosicion(piezaAjedrez pieza) {
        // Si la pieza es nula, devuelve la notación de peón predeterminada

        if (pieza == null) return "P";
        // Utilice una declaración switch para devolver la notación PGN apropiada para el tipo de pieza

        switch (pieza.getTipo().toLowerCase()) {
            case "king": return "K";
            case "queen": return "Q";
            case "rook": return "R";
            case "bishop": return "B";
            case "knight": return "N";
            default: return "P"; // Peon
        }
    }

    /**
     * Convierte una posición del tablero de ajedrez representada como un objeto `Posición` a la notación
     * algebraica correspondiente (por ejemplo, "e4").
     *
     * @param pos la posición del tablero de ajedrez que se convertirá
     * @return la  notación algebraica para la posición dada
     */

    private String posicionToAlgebra(Posicion pos) {
        char archivo = (char) ('a' + pos.getCol());
        int rank = 8 - pos.getFila();
        return "" + archivo + rank;
    }

    /**
     * Establece la posición inicial de las piezas de ajedrez en el tablero.
     */
    public void setupPosicionInicial() {
        // Lugar de los peones
        for (int col = 0; col < 8; col++) {
            lugarPieza("pawn", "white", (char) ('a' + col) + "2");
            lugarPieza("pawn", "black", (char) ('a' + col) + "7");
        }

        // Lugar de las otras piezas
        String[] pieza = {"rook", "knight", "bishop", "queen", "king", "bishop", "knight", "rook"};
        for (int col = 0; col < 8; col++) {
            lugarPieza(pieza[col], "white", (char) ('a' + col) + "1");
            lugarPieza(pieza[col], "black", (char) ('a' + col) + "8");
        }
    }
}