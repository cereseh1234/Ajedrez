package Controlador;

/**
 * Representa la posicion en el tablero de ajedrez.
 */
public class Posicion {
    /** La fila donde (0-7, tambien 0 es la parte superior de la fila) */
    private final int fila;

    /** La columna (0-7, donde 0 es la columna mas a la izquierda) */
    private final int col;

    /**
     * Construye una nueva posicion y especifica fila y columna.
     *
     * @param fila la fila (0-7)
     * @param col la columna
     */
    public Posicion(int fila, int col) {
        this.fila = fila;
        this.col = col;
    }

    /**
     * @return la fila de la posicion
     */
    public int getFila() { return fila; }

    /**
     * @return La columna de la poscion
     */
    public int getCol() { return col; }

    /**
     * Compara la posicion con otro objeto igual.
     * Si 2 posiciones son iguales  estan en la misma fila y columna.
     * Vital para HasMap.
     *
     * @param o El objeto a comparar
     * @return true Iguales, false Diferentes
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Posicion posicion = (Posicion) o;
        return fila == posicion.fila && col == posicion.col;
    }

    /**
     * Genera Hash code para la posicion.
     * la implementacion asegura que las posiciones con las misma cordenadas  tengan el mismo hashcode,
     * La formula aes: 31 * fila + col para crear un hash code unico para cada posicion.
     *
     * @return retorna un hash code con el valor de la posicion
     */
    @Override
    public int hashCode() {
        return 31 * fila + col;
    }

    /**
     * Retorna un string que representa la posicion
     * El formato es Posicion(fila,col)
     *
     * @return Retorna un string que representa la posicion
     */
    @Override
    public String toString() {
        return "Position(" + fila + "," + col + ")";
    }
}