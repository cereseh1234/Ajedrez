package Vista;

import Controlador.ControladorAjedrez;
import Controlador.Posicion;
import Modelo.ModeloTableroAjedrez;
import Modelo.validadorMoviminetoAjedrez;
import Modelo.piezaAjedrez;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Arrays;

/**
 * La clase VisorTableroAjedrez es responsable de representar el tablero de ajedrez.
 * Utiliza las clases ModeloTableroAjedrez y validadorMovimientoAjedrez para gestionar el estado del juego y validar los movimientos.
 */

public class VisorTableroAjedrez extends JPanel {
    //Las constantes
    private static final int TAMAÑO_CUADRO = 60;
    private static final Color CUADRO_CLARO = new Color(240, 217, 181);
    private static final Color CUADRO_OSCURO = new Color(181, 136, 99);
    private static final Color CUADRO_SELECCIONADO = new Color(186, 202, 68);
//Atributos
    private ModeloTableroAjedrez modelo;
    private validadorMoviminetoAjedrez validadorMovimiento;
    private Posicion posicionSeleccionada;
    private JLabel etiquetaEstatus;
    private boolean debugMode = false;
    private JLabel etiquetaContadorTurno;
    private ControladorAjedrez controlador;


    /**
     * Conjunto de fuentes que pueden mostrar símbolos de ajedrez Unicode.
     * Se intentarán usar en orden hasta encontrar una compatible.
     */
    private static final Font[] FUENTES_AJEDREZ = {
            new Font("DejaVu Sans", Font.PLAIN, 48),
            new Font("Arial Unicode MS", Font.PLAIN, 48),
            new Font("Segoe UI Symbol", Font.PLAIN, 48),
            new Font("Arial", Font.BOLD, 48)
    };

    /**
     * Desplazamiento en píxeles para el efecto de sombra de las piezas.
     */
    private static final int SOMBRA_DESPLAZAMIENTO = 1;

    /**
     * Borra la posición seleccionada actualmente.
     */

    private void limpiarSeleccion() {
        posicionSeleccionada = null;
    }

    /**
     * Convierte las coordenadas del mouse en una posición del tablero.
     *
     * @param e el MouseEvent que contiene las coordenadas del clic
     * @return la Posicion correspondiente en el tablero
     */
    private Posicion getClickedPosition(MouseEvent e) {
        int col = e.getX() / TAMAÑO_CUADRO;
        int row = e.getY() / TAMAÑO_CUADRO;
        return new Posicion(row, col);
    }




    /**
     * Realiza el movimiento de la pieza seleccionada y limpia la selección.
     *
     * @param destinationPos la posición destino del movimiento
     */
    private void realizarMovimiento(Posicion destinationPos) {
        controlador.handleMovimiento(posicionSeleccionada, destinationPos);
        limpiarSeleccion();
    }



    /**
     * Registra información de depuración sobre la pieza que se está dibujando.
     *
     * @param fila  La fila de la pieza
     * @param col   La columna de la pieza
     * @param pieza La pieza que se está dibujando
     */
    private void logDebugInfo(int fila, int col, piezaAjedrez pieza) {
        if (debugMode) {
            System.out.printf("Pieza dibujada en (%d,%d): %s%n", fila, col, pieza.toString());
        }
    }
    /**
     * Verifica si una pieza puede ser seleccionada basándose en el turno actual.
     *
     * @param pieza       la pieza a verificar
     * @param turnoActual el color del jugador actual
     * @return true si la pieza puede ser seleccionada
     */
    private boolean esPiezaSeleccionableValida(piezaAjedrez pieza, String turnoActual) {
        return pieza != null && pieza.getColor().toLowerCase().equals(turnoActual);
    }


    /**
     * Maneja la selección inicial de una pieza en el tablero
     *
     * @param clickedPos  Posición donde el usuario hizo click
     * @param turnoActual Color del jugador que tiene el turno actual ("blancas" o "negras")
     */
    private void handleSeleccionInicial(Posicion clickedPos, String turnoActual) {
        // Obtiene la pieza que está en la posición clickeada
        piezaAjedrez pieza = modelo.getPieza(clickedPos);

        // Verifica si la pieza puede ser seleccionada (si existe y pertenece al jugador actual)
        if (esPiezaSeleccionableValida(pieza, turnoActual)) {
            // Si la pieza es válida para seleccionar, guarda su posición
            posicionSeleccionada = clickedPos;
        }
    }

    /**
     * Maneja la selección alternativa cuando el movimiento no fue válido
     *
     * @param clickedPos  Posición donde el usuario hizo click
     * @param turnoActual Color del jugador que tiene el turno actual ("blancas" o "negras")
     */
    private void handleSeleccionAlternativa(Posicion clickedPos, String turnoActual) {
        // Obtiene la pieza en la nueva posición clickeada
        piezaAjedrez piezaClicada = modelo.getPieza(clickedPos);

        // Verifica si la nueva pieza clickeada puede ser seleccionada
        // (si existe y pertenece al jugador del turno actual)
        if (esPiezaSeleccionableValida(piezaClicada, turnoActual)) {
            // Si la pieza es válida, cambia la selección a esta nueva pieza
            posicionSeleccionada = clickedPos;
        } else {
            // Si la pieza no es válida, limpia la selección actual
            // (deselecciona cualquier pieza que estuviera seleccionada)
            limpiarSeleccion();
        }
    }

    /**
     * Maneja el click cuando ya hay una pieza seleccionada previamente
     *
     * @param clickedPos  Nueva posición donde el usuario hizo click
     * @param turnoActual Color del jugador que tiene el turno actual ("blancas" o "negras")
     */
    private void handleSiYaHayUnaSeleccion(Posicion clickedPos, String turnoActual) {
        // Verifica si el movimiento desde la posición seleccionada hasta la nueva posición es válido
        if (validadorMovimiento.MovimientoValidos(posicionSeleccionada, clickedPos)) {
            // Si el movimiento es válido, ejecuta el movimiento
            realizarMovimiento(clickedPos);
        } else {
            // Si el movimiento no es válido, intenta seleccionar otra pieza
            // (por ejemplo, si el usuario quiere cambiar la pieza seleccionada)
            handleSeleccionAlternativa(clickedPos, turnoActual);
        }
    }


    /**
     * Maneja los eventos de click del ratón en el tablero
     *
     * @param e Evento del ratón que contiene las coordenadas del click
     */
    public void handleMouseClick(MouseEvent e) {
        // Convierte las coordenadas del click a una posición del tablero
        Posicion clickedPos = getClickedPosition(e);

        // Obtiene el turno actual (blancas o negras) en minúsculas
        String turnoActual = validadorMovimiento.getTurnoActual().toLowerCase();

        if (posicionSeleccionada == null) {
            // Si no hay una pieza seleccionada previamente,
            // maneja la selección inicial de una pieza
            handleSeleccionInicial(clickedPos, turnoActual);
        } else {
            // Si ya hay una pieza seleccionada,
            // maneja el click para mover la pieza o seleccionar otra
            handleSiYaHayUnaSeleccion(clickedPos, turnoActual);
        }

        // Actualiza la visualización del tablero
        repaint();
    }

    //FinalizaRaton

    /**
     * Constructor de la clase VisorTableroAjedrez que inicializa la interfaz gráfica del tablero
     * @param modelo Referencia al modelo del tablero de ajedrez que contiene la lógica del juego
     */
    public VisorTableroAjedrez(ModeloTableroAjedrez modelo) {
        // Guarda la referencia al modelo del tablero
        this.modelo = modelo;

        // Crea un nuevo validador de movimientos asociado al modelo
        this.validadorMovimiento = new validadorMoviminetoAjedrez(modelo);

        // Define el tamaño del tablero multiplicando 8 casillas por el tamaño de cada cuadro
        setPreferredSize(new Dimension(8 * TAMAÑO_CUADRO, 8 * TAMAÑO_CUADRO));

        // Crea un panel para mostrar información del estado del juego
        // Utiliza GridLayout con 2 filas y 1 columna
        JPanel statusPanel = new JPanel(new GridLayout(2, 1));

        // Inicializa la etiqueta que muestra de quién es el turno
        etiquetaEstatus = new JLabel("Turno blanco");
        // Centra el texto de la etiqueta horizontalmente
        etiquetaEstatus.setHorizontalAlignment(SwingConstants.CENTER);

        // Inicializa la etiqueta que muestra el número de turno actual
        etiquetaContadorTurno = new JLabel("Turno: 1");
        // Centra el texto del contador horizontalmente
        etiquetaContadorTurno.setHorizontalAlignment(SwingConstants.CENTER);

        // Agrega las etiquetas al panel de estado
        statusPanel.add(etiquetaContadorTurno);
        statusPanel.add(etiquetaEstatus);

        // Configura el layout principal como BorderLayout(Colocacion de los componentes )
        setLayout(new BorderLayout());
        // Añade el panel de estado en la parte inferior de la ventana (Los botones)
        add(statusPanel, BorderLayout.SOUTH);

        // Agrega un escuchador de eventos del mouse para detectar clicks en el tablero
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                // Cuando se detecta un click, llama al método que maneja el evento
                handleMouseClick(e);
            }
        });
    }

    /**
     * Busca la primera fuente del array de fuentes.
     *
     * @return Font Primera fuente encontrada que puede mostrar símbolos de ajedrez, o null si ninguna es válida
     */
    private Font encontrarPrimeraFuenteValida() {
        // Utiliza Streams para procesar el array de fuentes disponibles
        return Arrays.stream(FUENTES_AJEDREZ)
                // Filtra las fuentes, manteniendo solo las que pueden mostrar
                // el símbolo del rey (♔) como prueba de compatibilidad
                .filter(font -> font.canDisplay('♔'))
                // Obtiene la primera fuente que cumple con el criterio
                .findFirst()
                // Si no se encuentra ninguna fuente válida, devuelve null
                .orElse(null);
    }



    /**
     * Obtiene una fuente válida para mostrar los símbolos de las piezas de ajedrez
     *
     * @return Font La fuente que se usará para mostrar las piezas, usando una fuente de respaldo si es necesario
     */
    private Font obtenerFuenteAjedrez() {
        // Intenta encontrar la primera fuente válida instalada en el sistema
        // que pueda mostrar símbolos de ajedrez
        Font fuenteAjedrez = encontrarPrimeraFuenteValida();

        // Si no se encontró ninguna fuente válida
        if (fuenteAjedrez == null) {
            // Registra una advertencia en el log de errores
            System.err.println("Error: Fuente no encontrada");

            // Usa la última fuente del array como respaldo
            // Esta es la fuente más básica que garantiza funcionalidad mínima
            fuenteAjedrez = FUENTES_AJEDREZ[FUENTES_AJEDREZ.length - 1];
        }

        // Registra la fuente que se está utilizando para propósitos de debugging
        System.out.println("Usando fuente: " + fuenteAjedrez.getFontName());

        return fuenteAjedrez;
    }



    /**
     * Establece el ControladorAjedrez para VisorTableroAjedrez.
     *
     * @param controlador el ControladorAjedrez que se utilizará
     */

    public void setControlador(ControladorAjedrez controlador) {
        this.controlador = controlador;
    }


    /**
     * Calcula la posición centrada para dibujar una pieza en su casilla.
     *
     * @param g2d     El contexto gráfico actual
     * @param simbolo El símbolo de la pieza a dibujar
     * @param fila    La fila de la casilla
     * @param col     La columna de la casilla
     * @return Point Las coordenadas x,y donde se debe dibujar la pieza
     */
    private Point calcularPosicionCentrada(Graphics2D g2d, String simbolo, int fila, int col) {
        //FontMetrics es una clase que proporciona información sobre las dimensiones del texto como el ancho del texto, altura, espacio ocupado.
        FontMetrics fm = g2d.getFontMetrics();
        //col * TAMAÑO_CUADRO: Obtiene la posición X inicial de la casilla
        //fm.stringWidth(simbolo): Obtiene el ancho del símbolo en píxeles
        //(TAMAÑO_CUADRO - fm.stringWidth(simbolo)) / 2: Calcula el espacio necesario para centrar horizontalmente
        int x = col * TAMAÑO_CUADRO + (TAMAÑO_CUADRO - fm.stringWidth(simbolo)) / 2;
        //fila * TAMAÑO_CUADRO: Obtiene la posición Y inicial de la casilla
        //fm.getHeight(): Obtiene la altura total del texto
        //fm.getDescent(): Obtiene la altura desde la linea base hasta la parte infeior
        //Centra verticalmente el texto en la casilla
        int y = fila * TAMAÑO_CUADRO + ((TAMAÑO_CUADRO + fm.getHeight()) / 2) - fm.getDescent();
        //Una pieza en la posición (2,3) del tablero
        //Un símbolo de ancho 20 píxeles y altura 30 píxeles
        //Ejemplo
        //x = 3 * 60 + (60 - 20) / 2 = 180 + 20 = 200
        //y = 2 * 60 + ((60 + 30) / 2) - descent ≈ 120 + 45 - descent
        return new Point(x, y);
    }
    /**
     * Dibuja una pieza con su efecto de sombra correspondiente.
     *
     * @param g2d           El contexto gráfico donde se dibujará
     * @param simbolo       El símbolo Unicode de la pieza
     * @param pos           La posición donde se dibujará la pieza
     * @param esPiezaBlanca true si la pieza es blanca, false si es negra
     */
    private void dibujarSombraYPieza(Graphics2D g2d, String simbolo, Point pos, boolean esPiezaBlanca) {
        //Si la pieza es blanca, la sombra será negra
        //Si la pieza es negra, la sombra será blanca
        //La sombra se dibuja desplazada según SHADOW_OFFSET
        g2d.setColor(esPiezaBlanca ? Color.BLACK : Color.WHITE);
        g2d.drawString(simbolo, pos.x + SOMBRA_DESPLAZAMIENTO, pos.y + SOMBRA_DESPLAZAMIENTO);
        //Si la pieza es blanca, se dibuja en blanco
        //Si la pieza es negra, se dibuja en negro
        //La pieza se dibuja en la posición exacta calculada

        // Dibujar pieza
        g2d.setColor(esPiezaBlanca ? Color.WHITE : Color.BLACK);
        g2d.drawString(simbolo, pos.x, pos.y);
    }

    /**
     * Dibuja una pieza individual de ajedrez en el tablero.
     *
     * @param g2d El contexto gráfico 2D donde se dibujará la pieza
     * @param pieza La pieza de ajedrez que se va a dibujar
     * @param fila La fila del tablero donde se dibujará la pieza (0-7)
     * @param col La columna del tablero donde se dibujará la pieza (0-7)
     */
    private void dibujarPiezaIndividual(Graphics2D g2d, piezaAjedrez pieza, int fila, int col) {
        // Obtiene el símbolo Unicode que representa la pieza
        String simbolo = String.valueOf(pieza.getSimbolo());

        // Calcula la posición centrada para dibujar la pieza en la casilla correspondiente
        Point posicion = calcularPosicionCentrada(g2d, simbolo, fila, col);

        // Determina si la pieza es blanca comparando su color con la cadena "white"
        boolean esPiezaBlanca = pieza.getColor().equals("white");
         // Dibuja la sombra y la pieza:

        dibujarSombraYPieza(g2d, simbolo, posicion, esPiezaBlanca);
    }


        /**
         * Dibuja una pieza de ajedrez en una posición específica del tablero si existe una pieza en esa posición.
         * Este método verifica primero si hay una pieza en la posición dada y, si existe,
         * procede a dibujarla utilizando el método dibujarPiezaIndividual.
         * @param g2d El contexto gráfico 2D donde se dibujará la pieza
         * @param fila La fila del tablero donde se verificará y dibujará la pieza (0-7)
         * @param col La columna del tablero donde se verificará y dibujará la pieza (0-7)
         */
    private void dibujarPiezaVerificacionPosicion(Graphics2D g2d, int fila, int col) {
        Posicion pos = new Posicion(fila, col);
        //devuelve el objeto piezaAjedrez que está ubicado en la posición especificada, si no hay nada devuelve null.
        piezaAjedrez pieza = modelo.getPieza(pos);
        //Se verifica si hay una pieza en la posición obtenida. Si pieza no es nulo, significa que hay una pieza que debe ser dibujada.
        if (pieza != null) {
            //Si hay una pieza,registra información sobre el estado del juego
            logDebugInfo(fila, col, pieza);
            // Calcular la posición centrada y dibuja el símbolo de la pieza en el tablero.
            dibujarPiezaIndividual(g2d, pieza, fila, col);
        }
    }


    /**
     * Dibuja la pieza que esta en esa posicon
     * @param g2d El contexto gráfico que se utiliza para dibujar las piezas en el tablero.
     */
    private void dibujarTodasLasPiezas(Graphics2D g2d) {

        for (int fila = 0; fila < 8; fila++) {
            for (int col = 0; col < 8; col++) {
                //se encarga de verificar si hay una pieza en la posición especificada y, si la hay, la dibuja en el contexto gráfico
                dibujarPiezaVerificacionPosicion(g2d, fila, col);
            }
        }
    }
    /**
     * Configura las opciones de renderizado para mejorar la calidad visual
     *
     * @param g Objeto Graphics básico que será mejorado
     * @return Graphics2D configurado con opciones de alta calidad
     */
    private Graphics2D configuararGraficos(Graphics g) {
        // Convierte el objeto Graphics básico a Graphics2D
        // para acceder a opciones avanzadas de renderizado
        Graphics2D g2d = (Graphics2D) g;

        // Activa el antialiasing general para suavizar bordes de formas y líneas
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);

        // Activa el antialiasing específico para texto
        // mejorando la legibilidad de los símbolos de las piezas
        g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        return g2d;
    }



    /**
     * Configuración inicial del entorno gráfico, lienzo
     *
     * @param g Objeto Graphics base que será convertido a Graphics2D para mejor calidad
     */
    private void dibujarPiezas(Graphics g) {
        // Convierte el objeto Graphics a Graphics2D y configura sus propiedades
        // para obtener mejor calidad de renderizado
        Graphics2D g2d = configuararGraficos(g);

        // Obtiene la fuente especial que contiene los símbolos de las piezas de ajedrez
        Font chessFont = obtenerFuenteAjedrez();

        // Aplica la fuente de ajedrez al contexto gráfico
        g2d.setFont(chessFont);

        // Dibuja todas las piezas en sus posiciones actuales usando
        // los símbolos de la fuente de ajedrez
        dibujarTodasLasPiezas(g2d);
    }
    /**
     * Dibuja el patrón de cuadros del tablero de ajedrez
     *
     * @param g Objeto Graphics utilizado para realizar el dibujado
     */
    private void dibujarTabla(Graphics g) {
        // Recorre las 8 filas del tablero
        for (int fila = 0; fila < 8; fila++) {
            // Recorre las 8 columnas del tablero
            for (int col = 0; col < 8; col++) {
                // Determina si el cuadro debe ser claro basándose en la suma de fila y columna
                // Si la suma es par, el cuadro es claro; si es impar, es oscuro
                boolean isLight = (fila + col) % 2 == 0;

                // Establece el color del cuadro según si debe ser claro u oscuro
                g.setColor(isLight ? CUADRO_CLARO : CUADRO_OSCURO);

                // Dibuja un rectángulo relleno en la posición correspondiente
                // Las coordenadas se calculan multiplicando la fila/columna por el tamaño del cuadro
                g.fillRect(col * TAMAÑO_CUADRO, fila * TAMAÑO_CUADRO,
                        TAMAÑO_CUADRO, TAMAÑO_CUADRO);
            }
        }
    }

    /**
     * este método se llame cuando el usuario selecciona una casilla en el tablero de
     * ajedrez o cuando se resalta un movimiento, lo que permite al usuario identificar fácilmente
     * la casilla seleccionada o resaltada en la representación visual del tablero de ajedrez.
     *
     * @param g     el objeto Graphics utilizado para dibujar en el tablero de ajedrez.
     * @param pos   el objeto Position que representa el cuadrado que se va a resaltar.
     * @param color el color que se utilizará para resaltar el cuadrado.
     */

    private void resaltarCuadro(Graphics g, Posicion pos, Color color) {
        g.setColor(color);
        g.fillRect(pos.getCol() * TAMAÑO_CUADRO, pos.getFila() * TAMAÑO_CUADRO, TAMAÑO_CUADRO, TAMAÑO_CUADRO);
    }


    /**
     * Sobrescribe el método paintComponent para dibujar el tablero de ajedrez
     * y todos sus elementos visuales
     *
     * @param g Objeto Graphics utilizado para realizar el dibujado
     */
    @Override
    protected void paintComponent(Graphics g) {
        // Llama al método de la clase padre para mantener el comportamiento básico
        super.paintComponent(g);

        // Dibuja el tablero base con el patrón de cuadros blancos y negros
        dibujarTabla(g);

        // Si hay una pieza seleccionada, resalta el cuadro donde está
        if (posicionSeleccionada != null) {
            // Dibuja un resaltado en el cuadro seleccionado usando el color definido
            resaltarCuadro(g, posicionSeleccionada, CUADRO_SELECCIONADO);
        }

        // Dibuja todas las piezas en sus posiciones actuales sobre el tablero
        dibujarPiezas(g);
    }

    /**
     * Establece la casilla seleccionada en el tablero de ajedrez.
     *
     * @param pos La posición de la casilla seleccionada
     */


    public void setCuadroSeleccionado(Posicion pos) {
        this.posicionSeleccionada = pos;
        repaint();
    }

    /**
     * Establece el mensaje de estado que se muestra en la parte inferior del tablero de ajedrez.
     *
     * @param mensaje el mensaje de estado que se mostrará
     */

    public void setMensajeEstatus(String mensaje) {
        if (etiquetaEstatus != null) {
            etiquetaEstatus.setText(mensaje);
        }
    }



    /**
     * Actualiza el contador de turnos que se muestra en la parte inferior del tablero de ajedrez.
     *
     * @param turno el número de turno actual
     */

    public void actualizarContadorTurno(int turno) {
        if (etiquetaContadorTurno != null) {
            etiquetaContadorTurno.setText("Turno: " + turno);
        }
    }

    /**
     * Muestra el cuadro de diálogo de fin del juego y solicita al usuario que guarde el juego.
     *
     * @param ganador el ganador del juego (ya sea "Blanco" o "Negro")
     */


    public void juegoTerminado(String ganador) {
        //Muestra el mensaje que incluye el nombre del ganador y pregunta si desea guardar el juego.
        //Tipo de mensaje: Se utiliza JOptionPane.INFORMATION_MESSAGE, lo que indica que se trata de un mensaje informativo.
        int elegir = JOptionPane.showConfirmDialog( //el resultado de la eleccion se guarda en eleguir
                this,
                ganador + " - Quieres guardar el juego?",
                "Juego terminado",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.INFORMATION_MESSAGE
        );
//Si el usuario selecciona "Sí", se verifica si el objeto controlador no es nulo.
        if (elegir == JOptionPane.YES_OPTION) {
            if (controlador != null) {
                //  Para guardar el estado actual del juego.
                controlador.handleGuardarJuego();
            }
        }
    }

    /**
     * Muestra un diálogo para que el jugador elija la pieza de coronación cuando un peón llega al final
     *
     * @param color Color del jugador que está coronando ("blancas" o "negras")
     * @return String Nombre de la pieza elegida en minúsculas, "queen" por defecto
     */
    public String showDialogoCoronacion(String color) {
        // Define las opciones disponibles para la coronación
        Object[] opciones = {"Dama", "Torre", "Alfil", "Caballo"};

        // Construye el título del diálogo convirtiendo en mayuscula la primera letra del color
        // Ejemplo: "blancas" -> "Blancas Coronacion Peon"
        String titulo = color.substring(0, 1).toUpperCase() + color.substring(1) + " Coronacion Peon";

        // Muestra el diálogo de selección con las opciones disponibles
        int elegir = JOptionPane.showOptionDialog(this,
                "Elige la pieza:",            // Mensaje
                titulo,                       // Título
                JOptionPane.DEFAULT_OPTION,   // Tipo de opciones por defecto
                JOptionPane.QUESTION_MESSAGE, // Tipo de mensaje
                null,                        // Sin ícono personalizado
                opciones,                    // Array de opciones disponibles
                opciones[0]);                // Opción por defecto (Dama)

        // Si el usuario seleccionó una opción válida (no cerró el diálogo)
        if (elegir >= 0) {
            // Devuelve el nombre de la pieza elegida en minúsculas
            return opciones[elegir].toString().toLowerCase();
        }

        // Si el usuario cerró el diálogo sin elegir, devuelve "dama" por defecto
        return "queen";
    }
}