package Controlador;

import Modelo.BasicPiezaAjedrez;
import Modelo.ModeloTableroAjedrez;
import Modelo.piezaAjedrez;
import Modelo.validadorMoviminetoAjedrez;
import Vista.VisorTableroAjedrez;

import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JFileChooser;
import java.io.File;

/**
 * Controladorajedrez es la clase responsable para controlar interacciones de usuarios, actualizar el estado del juego
 * y coordinar entre las clases ModeloTableroAjedrez y la vista.
 */
//Aqui
public class ControladorAjedrez {
    private static final int TAMAÑO_CUADRADO = 60;
    private final ModeloTableroAjedrez modelo;
    private final VisorTableroAjedrez vista;
    private final HandlerPGNTiempoReal gestorPGN;
    private final validadorMoviminetoAjedrez validadorMovimiento;
    private Posicion posicionSeleccionada;
//Aqui
    public ControladorAjedrez(ModeloTableroAjedrez modelo, VisorTableroAjedrez vista, HandlerPGNTiempoReal gestorPGN) {
        validarParametros(modelo, vista);

        this.modelo = modelo;
        this.vista = vista;
        this.gestorPGN = gestorPGN;
        this.validadorMovimiento = new validadorMoviminetoAjedrez(this.modelo);

        inicializarTablero();
        configurarMouseListener();
    }

    /**
     * Valida que los parámetros del controlador no sean nulos
     * @param modelo El modelo del tablero de ajedrez
     * @param vista La vista del tablero de ajedrez
     * @throws IllegalArgumentException si algún parámetro es nulo
     */
    private void validarParametros(ModeloTableroAjedrez modelo, VisorTableroAjedrez vista) {
        if (modelo == null) throw new IllegalArgumentException("El modelo no puede ser nulo");
        if (vista == null) throw new IllegalArgumentException("La vista no puede ser nula");
    }
    //Aqui
    /**
     * Clase auxiliar para encapsular la información de un movimiento
     */
    private static class InfoMovimiento {
        final piezaAjedrez pieza;
        final boolean capturada;

        /**
         * Constructor de la información del movimiento
         *
         * @param pieza     Pieza que se mueve
         * @param capturada Indica si se capturó una pieza
         */
        InfoMovimiento(piezaAjedrez pieza, boolean capturada) {
            this.pieza = pieza;
            this.capturada = capturada;
        }
    }
    /**
     * Prepara la información necesaria para realizar un movimiento
     * @param posicionDestino Posición final de la pieza
     * @return Información del movimiento
     */
    private InfoMovimiento prepararMovimiento(Posicion posicionDestino) {
        piezaAjedrez pieza = modelo.getPieza(posicionSeleccionada);
        boolean capturada = modelo.getPieza(posicionDestino) != null;
        return new InfoMovimiento(pieza, capturada);
    }

    /**
     * Actualiza el estatus del juego y el turno
     */
    private void actualizarEstatusJuego() {
        String jugadorActual = validadorMovimiento.getTurnoActual();
        vista.setMensajeEstatus(jugadorActual.substring(0, 1).toUpperCase() +
                jugadorActual.substring(1) + " turno" );
        vista.actualizarContadorTurno(validadorMovimiento.getContadorTurno());
    }


    /**
     * Configura el listener del mouse para capturar los clicks del usuario
     */
    private void configurarMouseListener() {
        vista.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                manejarClickMouse(e);
            }
        });
    }


    /**
     * Convierte las coordenadas del click en una posición del tablero
     * @param e Evento del mouse
     * @return Posición correspondiente en el tablero
     */
    private Posicion obtenerPosicionClick(MouseEvent e) {
        int col = e.getX() / TAMAÑO_CUADRADO;
        int fila = e.getY() / TAMAÑO_CUADRADO;
        return new Posicion(fila, col);
    }


    //Aqui
    /**
     * Procesa el primer click del usuario
     * Verifica si hay una pieza válida en la posición seleccionada
     * @param posicionClikeada Posición donde el usuario hizo click
     */
    private void manejarPrimerClick(Posicion posicionClikeada) {
        piezaAjedrez pieza = modelo.getPieza(posicionClikeada);
        if (esPiezaTurno(pieza)) {
            posicionSeleccionada = posicionClikeada;
            vista.setCuadroSeleccionado(posicionClikeada);
        }
    }

    /**
     * Verifica si la pieza seleccionada es válida para mover
     * Comprueba que la pieza existe y corresponde al turno actual
     * @param pieza Pieza a validar
     * @return true si la pieza es válida para mover
     */
    private boolean esPiezaTurno(piezaAjedrez pieza) {
        return pieza != null && pieza.getColor().equals(validadorMovimiento.getTurnoActual());
    }


    /**
     * Convierte una posición del tablero de ajedrez representada como un objeto `Posición` a la notación
     * algebraica correspondiente (por ejemplo, "e4").
     *
     * @param pos la posición del tablero de ajedrez que se convertirá
     * @return la  notación algebraica para la posición dada
     */

    private String posicionToAlgebra(Posicion pos) {
        char archivo = (char) ('a' + pos.getCol());
        int rank = 8 - pos.getFila();
        return "" + archivo + rank;
    }

    /**
     * Conveierte las piezas del juego en su representación estándar en notación PGN
     * @param pieza Un objeto que representa la pieza de ajedrez
     * @return Retorna una cadena que representa la notación PGN para la pieza especificada.
     */
    private String getPGNPPiezaPosicion(piezaAjedrez pieza) {
        // Si la pieza es nula, devuelve la notación de peón predeterminada

        if (pieza == null) return "P";
        // Utilice una declaración switch para devolver la notación PGN apropiada para el tipo de pieza

        switch (pieza.getTipo().toLowerCase()) {
            case "king": return "K";
            case "queen": return "Q";
            case "rook": return "R";
            case "bishop": return "B";
            case "knight": return "N";
            default: return "P"; // Peon
        }
    }


    /**
     * Registra el movimiento en notación PGN
     * @param posicionDestino Posición final de la pieza
     * @param info Información del movimiento
     */
    private void registrarMovimientoPGN(Posicion posicionDestino, InfoMovimiento info) {
        String fromCuadrado = posicionToAlgebra(posicionSeleccionada);
        String toCuadrado = posicionToAlgebra(posicionDestino);
        String notacionPieza = getPGNPPiezaPosicion(info.pieza);
        gestorPGN.gabarMovimiento(fromCuadrado, toCuadrado, notacionPieza, info.capturada);
    }

    /**
     * Ejecuta el movimiento y registra la notación PGN
     * @param posicionDestino Posición final de la pieza
     * @param info Información del movimiento
     */
    private void ejecutarMovimiento(Posicion posicionDestino, InfoMovimiento info) {
        modelo.moverPieza(posicionSeleccionada, posicionDestino);
        registrarMovimientoPGN(posicionDestino, info);
    }

    /**
     * Determina el ganador del juego basado en el turno actual
     * Si es el turno de las blancas, ganaron las negras y viceversa
     * @return String con el color del jugador ganador ("White" o "Black")
     */
    private String determinarGanador() {
        return validadorMovimiento.getTurnoActual().equals("white") ? "Black" : "White";
    }
    /**
     * Maneja la situación de jaque mate
     * Determina el ganador y registra el resultado
     */

    private void manejarJakeMate() {
        String ganador = determinarGanador();
        String resultado = ganador.equals("White") ? "1-0" : "0-1";

        gestorPGN.finJuego(resultado);
        System.out.println(ganador + " Jakemate!");
        notificarFinJuego(ganador);
    }

    /**
     * Maneja la situación de empate (tablas)
     * Registra el resultado y notifica a la interfaz
     */
    private void manejarEmpate() {
        gestorPGN.finJuego("1/2-1/2");
        notificarFinJuego("Draw by stalemate");
    }

    /**
     * Muestra un mensaje en la interfaz cuando hay jaque
     * @param turnoActual Color del jugador en jaque
     */
    private void mostrarMensajeJake(String turnoActual) {
        String mensajeJake = capitalizarPrimera(turnoActual) + " esta en Jake!";
        vista.setMensajeEstatus(mensajeJake);
    }


    /**
     * Verifica el estado actual del juego
     * Comprueba situaciones de jaque mate, tablas o jaque
     */
    private void verificarEstadoJuego() {
        if (validadorMovimiento.jakeMate()) {
            manejarJakeMate();
        } else if (validadorMovimiento.esAhogado()) {
            manejarEmpate();
        } else if (validadorMovimiento.enJake(validadorMovimiento.getTurnoActual())) {
            mostrarMensajeJake(validadorMovimiento.getTurnoActual());
        } else {
            actualizarEstatusJuego();
        }
    }

    /**
     * Ejecuta la secuencia completa de un movimiento
     * @param posicionDestino Posición final de la pieza
     */
    private void realizarMovimiento(Posicion posicionDestino) {
        InfoMovimiento infoMovimiento = prepararMovimiento(posicionDestino);
        ejecutarMovimiento(posicionDestino, infoMovimiento);
        validadorMovimiento.cambiarTurno();
        verificarEstadoJuego();
    }


    //Aqui

    /**
     * Maneja la lógica principal de un movimiento en el juego
     * Valida el movimiento, ejecuta el movimiento si es válido y verifica el estado del juego
     * @param from Posición inicial de la pieza
     * @param to Posición final de la pieza
     */
    public void handleMovimiento(Posicion from, Posicion to) {
        // Validaciones iniciales
        if (!validadorMovimiento.MovimientoValidos(from, to)) {
            return;
        }

        piezaAjedrez piezaMoviendo = modelo.getPieza(from);
        if (piezaMoviendo == null || !isTurnoPieza(piezaMoviendo)) {
            return;
        }

        // Ejecutar el movimiento
        realizarMovimiento(from, to);
        validadorMovimiento.cambiarTurno();

        // Verificar estado del juego
        verificarEstadoJuego();
    }



    /**
     * Limpia la selección actual de la pieza
     */
    private void limpiarSeleccion() {
        posicionSeleccionada = null;
        vista.setCuadroSeleccionado(null);
    }

    /**
     * Procesa el segundo click del usuario
     * Verifica si el movimiento es válido y lo ejecuta
     * @param posicionClikeada Posición destino del movimiento
     */
    private void manejarSegundoClick(Posicion posicionClikeada) {
        if (validadorMovimiento.MovimientoValidos(posicionSeleccionada, posicionClikeada)) {
            realizarMovimiento(posicionClikeada);
        }
        limpiarSeleccion();
    }

    /**
     * Maneja los eventos de click del mouse en el tablero
     * Procesa el primer click (selección de pieza) y el segundo click (movimiento)
     * @param e Evento del mouse
     */
    private void manejarClickMouse(MouseEvent e) {
        Posicion posicionClikeada = obtenerPosicionClick(e);

        if (posicionSeleccionada == null) {
            manejarPrimerClick(posicionClikeada);
        } else {
            manejarSegundoClick(posicionClikeada);
        }

        vista.repaint();
    }




    /**
     * Notifica a la interfaz sobre el fin del juego
     * @param mensaje Mensaje a mostrar en la interfaz
     */
    private void notificarFinJuego(String mensaje) {
        SwingUtilities.invokeLater(() -> vista.juegoTerminado(mensaje));
    }







    /**
     * Coloca una pieza de ajedrez en el tablero en la posicion especificada
     * Convierte la notacion algebraica (por ejemplo"e4")en indices de matriz y crea la pieza adecuada.
     *
     * @param tipoPieza El tipo de pieza
     * @param color     El color de la pieza
     * @param posicion  La posicion en notacion algebraica
     */

    public void lugarPieza(String tipoPieza, String color, String posicion) {
        try {
            if (posicion == null || posicion.length() != 2) {
                throw new IllegalArgumentException("Posición inválida: " + posicion);
            }

            // Converte de notación algebraica a índices de matriz

            int col = posicion.charAt(0) - 'a';
            int fila = 8 - (posicion.charAt(1) - '0');

            if (fila >= 0 && fila < 8 && col >= 0 && col < 8) {


                Posicion pos = new Posicion(fila, col);
                piezaAjedrez pieza = crearPieza(tipoPieza, color);
                if (pieza != null) {
                    modelo.lugarPieza(pos, pieza);
                    vista.repaint(); // Asegura que la vista se actualice después de cada pieza

                } else
                    System.err.println("Error: No se pudo crear la pieza " + tipoPieza);
            }
        } catch (Exception e) {
            System.err.println("Error lugar pieza posicion " + posicion + ": " + e.getMessage());
        }
    }

    //Aqui
    public void handleGuardarJuego() {
        // Obtiene el turno actual para determinar el ganador

        String ganador = validadorMovimiento.getTurnoActual().equals("white") ? "Black" : "White";
        String resultado = ganador.equals("White") ? "1-0" : "0-1";

        // Actualiza el resultado del juego en el controlador PGN

        gestorPGN.finJuego(resultado);

        // Crea el selector de archivos para guardar

        JFileChooser chooserArchivo = new JFileChooser();
        chooserArchivo.setDialogTitle("Guardar PGN File");

        // Establezca el nombre de archivo predeterminado utilizando la información del juego

        String nombrePorDefectoArchivo = String.format("%s_vs_%s.pgn",
                gestorPGN.getEncabezado("White"),
                gestorPGN.getEncabezado("Black"));
        chooserArchivo.setSelectedFile(new File(nombrePorDefectoArchivo));

        // // Muestra dialogo de guardar
        int returnVal = chooserArchivo.showSaveDialog(vista);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            File archivo = chooserArchivo.getSelectedFile();
            // Añade la extension pgn si no esta presente
            if (!archivo.getName().toLowerCase().endsWith(".pgn")) {
                archivo = new File(archivo.getAbsolutePath() + ".pgn");
            }
            gestorPGN.guardarArchivoComo(archivo.getAbsolutePath());
            JOptionPane.showMessageDialog(vista,
                    "JuegoGuardadoCorrectamente: " + archivo.getName(),
                    "GuardadoCorrectamente",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }




    /**
     * Crea un nuevo objeto `PiezaAjedrez` basado en el tipo y color de pieza especificados.
     *
     * @param tipo  el tipo de pieza de ajedrez
     * @param color el color de la pieza de ajedrez
     * @return un nuevo objeto  que representa el tipo y color de pieza especificados
     * @throws IllegalArgumentException si el tipo de pieza proporcionado no es válido
     */

    //Aqui
    private piezaAjedrez crearPieza(String tipo, String color) {
        char simbolo = switch (tipo.toLowerCase()) {
            case "king" -> color.equals("white") ? '♔' : '♚';
            case "queen" -> color.equals("white") ? '♕' : '♛';
            case "rook" -> color.equals("white") ? '♖' : '♜';
            case "bishop" -> color.equals("white") ? '♗' : '♝';
            case "knight" -> color.equals("white") ? '♘' : '♞';
            case "pawn" -> color.equals("white") ? '♙' : '♟';
            default -> throw new IllegalArgumentException("Tipo de pieza invalida: " + tipo);
        };
        return new BasicPiezaAjedrez(simbolo, color, tipo);
    }




    /**
     * Verifica si la pieza pertenece al jugador del turno actual
     * @param pieza Pieza a verificar
     * @return true si la pieza pertenece al jugador del turno actual
     */
    private boolean isTurnoPieza(piezaAjedrez pieza) {
        return pieza.getColor().equalsIgnoreCase(validadorMovimiento.getTurnoActual());
    }

    /**
     * Maneja casos especiales como la coronación de peones
     * @param from Posición inicial de la pieza
     * @param to Posición final de la pieza
     */
    private void realizarMovimiento(Posicion from, Posicion to) {
        handleCoronacionPeon(from, to);
    }




    private String capitalizarPrimera(String texto) {
        return texto.substring(0, 1).toUpperCase() + texto.substring(1);
    }
    /**
     * Maneja la promoción de un peón que ha llegado al extremo opuesto del tablero.
     *
     * @param from la posición inicial del movimiento del peón
     * @param to la posición de destino del movimiento del peón
     */

    private void handleCoronacionPeon(Posicion from, Posicion to) {
        piezaAjedrez pieza = modelo.getPieza(from);

        // Obtene la pieza en la posición inicial

        if (pieza.getTipo().equalsIgnoreCase("pawn")) {
            int obtenerFila = to.getFila();
            boolean esPeonBlanco = pieza.getColor().equalsIgnoreCase("white");

            //Revisa si el peon alcanzo la posicion necesaria (fila 0 Blanco, fila 7 Negro)
            if ((esPeonBlanco && obtenerFila == 0) || (!esPeonBlanco && obtenerFila == 7)) {
                String elegirCoronacion = vista.showDialogoCoronacion(pieza.getColor());
                if (elegirCoronacion != null) {
                    // Registra los detalles básicos del movimiento

                    boolean capturada = modelo.getPieza(to) != null;
                    String fromCuadrado = posicionToAlgebra(from);
                    String toCuadro = posicionToAlgebra(to);

                    //Retira el peón de su posición original

                    modelo.removerPieza(from);

                    //Retira cualquier pieza capturada en el destino

                    if (capturada) {
                        modelo.removerPieza(to);
                    }

                    //Crear y colocar la nueva pieza promocionada

                    piezaAjedrez piezaCoronada = crearPieza(elegirCoronacion, pieza.getColor());
                    modelo.lugarPieza(to, piezaCoronada);

                    //Graba el movimiento con información de la promoción

                    gestorPGN.gabarMovimiento(fromCuadrado, toCuadro, "P", capturada);
                    String notacionCoronation = "=" + getPGNPPiezaPosicion(piezaCoronada);
                    gestorPGN.appendUltimoMovimiento(notacionCoronation);
                }
                return;
            }
        }
        // Si no es una coronacion del peón, simplemente mueve la pieza

        modelo.moverPieza(from, to);
    }




    /**
     * Establece la posición inicial de las piezas de ajedrez en el tablero.
     */
    public void setupPosicionInicial() {
        // Lugar de los peones
        for (int col = 0; col < 8; col++) {
            lugarPieza("pawn", "white", (char) ('a' + col) + "2");
            lugarPieza("pawn", "black", (char) ('a' + col) + "7");
        }

        // Lugar de las otras piezas
        String[] pieza = {"rook", "knight", "bishop", "queen", "king", "bishop", "knight", "rook"};
        for (int col = 0; col < 8; col++) {
            lugarPieza(pieza[col], "white", (char) ('a' + col) + "1");
            lugarPieza(pieza[col], "black", (char) ('a' + col) + "8");
        }
    }
    /**
     * Inicializa el tablero de ajedrez
     * Configura la vista con el controlador y establece la posición inicial de las piezas
     */
    private void inicializarTablero() {
        vista.setControlador(this);
        setupPosicionInicial();
        actualizarEstatusJuego();
    }
}