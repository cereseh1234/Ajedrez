package Controlador;

import Modelo.ModeloTableroAjedrez;
import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class HandlerPGNTiempoReal {
    private final ModeloTableroAjedrez modelo;
    private String rutaArchivoJuego;
    private List<String> movimiento;
    private Map<String, String> encabezado;
    private int numeroMovimiento;
    private String resultadoJuego;

    /**
     * Maneja la creación y administración en tiempo real de archivos PGN para partidas de ajedrez.
     * Esta clase proporciona funcionalidad para registrar movimientos, administrar metadatos de partidas y guardar partidas en formato PGN
     * mientras se están jugando.
     */


    public HandlerPGNTiempoReal(ModeloTableroAjedrez modelo, String rutaArchivo, String nombreEvento, String nombreSitio,
                                String jugadorBlanco, String jugadorNegro,
                                String eloBlanco, String eloNegro, String round) {
        /** El modelo de tablero de ajedrez */

        this.modelo = modelo;
        /** La ruta del archivo donde se guardará el archivo PGN */

        this.rutaArchivoJuego = rutaArchivo;
        /** Lista de movimientos registrados en notación PGN */
        this.movimiento = new ArrayList<>();
        /** Mapa que contiene los encabezados de metadatos del juego */
        this.encabezado = new HashMap<>();
        /** Número de movimiento actual en el juego */
        this.numeroMovimiento = 1;
        /** Resultado actual del juego */
        this.resultadoJuego = "*";
        initializeHeaders(nombreEvento, nombreSitio, jugadorBlanco, jugadorNegro, eloBlanco, eloNegro, round);
    }

    /**
     * Inicializa los encabezados PGN con metadatos del juego.
     * Configura los encabezados PGN estándar, incluidos los detalles del evento, la información del jugador y la fecha actual.
     *
     * @param nombreEvento Nombre del evento de ajedrez
     * @param nombreSitio Ubicación donde se juega la partida
     * @param jugadorBlanco Nombre del jugador con piezas blancas
     * @param jugadorNegro Nombre del jugador con piezas negras
     * @param eloBlanco Calificación Elo del jugador blanco
     * @param eloNegro Calificación Elo del jugador negro
     * @param round Número de ronda actual
     */


    private void initializeHeaders(String nombreEvento, String nombreSitio,
                                   String jugadorBlanco, String jugadorNegro,
                                   String eloBlanco, String eloNegro, String round) {
        LocalDate today = LocalDate.now();
        String fechaFormato = today.format(DateTimeFormatter.ofPattern("yyyy.MM.dd"));

        encabezado.put("Evento", nombreEvento);
        encabezado.put("Sitio", nombreSitio);
        encabezado.put("Fecha", fechaFormato);
        encabezado.put("Round", round);
        encabezado.put("Blanco", jugadorBlanco);
        encabezado.put("Negro", jugadorNegro);
        encabezado.put("Resultado", resultadoJuego);
        encabezado.put("eloBlanco", eloBlanco);
        encabezado.put("eloNegro", eloNegro);
        encabezado.put("FechaEvento", fechaFormato);
    }

    /**
     * Registra un movimiento de ajedrez en notación PGN y lo guarda en el archivo de juego.
     *
     * @param fromPos Posición inicial del movimiento
     * @param toPos Posición final del movimiento
     * @param pieza La pieza que se movió
     * @param capturado Verdadero si este movimiento captura una pieza del oponente
     */

    public void gabarMovimiento(String fromPos, String toPos, String pieza, boolean capturado) {
        // Agrega el  número del movimiento para cada movimiento
        //Crea una cadena para el movimiento.
        //Agrega el número de movimiento seguido de un punto y un espacio.
        //Ejemplo: "1." para el primer movimiento
        StringBuilder notacionMovimiento = new StringBuilder();
        notacionMovimiento.append(numeroMovimiento).append(". ");

        // Añade la letra de la pieza (excepto los peones)


        if (!pieza.equalsIgnoreCase("P")) {
            notacionMovimiento.append(pieza.toUpperCase());
        }

        //Añade la posición inicial
        //Si hay una captura, agrega "x"
        //Añade la posición final



        notacionMovimiento.append(fromPos);
        if (capturado) {
            notacionMovimiento.append("x");
        }
        notacionMovimiento.append(toPos);
        //Añade el movimiento a la lista de movimientos.
        //Incrementa el contador de movimientos
        //Guarda el estado del juego.

        movimiento.add(notacionMovimiento.toString());

        // Incrementa el número de movimiento para cada movimiento

        numeroMovimiento++;
        // Guarda después de cada movimiento
        guardarJuego();
    }

    /**
     * Guarda el estado actual del juego en el archivo PGN.
     * Escribe los encabezados y los movimientos en formato PGN estándar.
     */

    public void guardarJuego() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaArchivoJuego))) { //Garanriza que se guarde
            // Escribe los encabezados en el orden PGN estándar

            String[] ordenEstandar = {
                    "Evento", "Sitio", "Fecha", "Round", "Blanco", "Negro",
                    "Resultado", "eloBlanco", "eloNegro", "FechaEvento"
            };

            for (String headerKey : ordenEstandar) {
                String valor = encabezado.get(headerKey);
                //Si el valor existe ( valor != null), lo formatea como [HeaderKey "Value"]
                if (valor != null) {
                    //%s: Marcador de posición para headerKey, por ejemplo, "Evento".
                    //\"%s\": Marcador de posición para el valor, rodeado de comillas de escape ( \").
                    //]: Cierra el él
                    //%n:Agrega un carácter de nueva línea al final para saltos de línea independientes de la plataforma.
                    writer.write(String.format("[%s \"%s\"]%n", headerKey, valor));
                }
            }
            writer.write("\n");

            // Escribe los movimientos con el nuevo formato
            //: Escribe la lista de movimientos en una sola línea, separados por espacios.
            for (String mover : movimiento) {
                writer.write(mover + " ");
            }

            //Agrega el resultado del juego al final si el juego ha terminado

            if (!resultadoJuego.equals("*")) {
                writer.write(resultadoJuego);
            }

            writer.write("\n");
        } catch (IOException e) {
            System.err.println("Error al guarda el archivo PGN : " + e.getMessage());
        }
    }

    /**
     * Recupera un valor de encabezado de los metadatos del juego.
     *
     * @param key La clave de encabezado que se recuperará
     * @return El valor asociado con la clave de encabezado
     */
    public String getEncabezado(String key) {
        return encabezado.get(key);
    }
    /**
     * Guarda el juego actual en una nueva ubicación de archivo.
     *
     * @param nuevaRutaArchivo La nueva ruta de archivo donde se debe guardar el juego
     */


    public void guardarArchivoComo(String nuevaRutaArchivo) {
        try {
            // Primero guarda el estado actual para asegurarse de que esté actualizado

            guardarJuego();
            // Copia el archivo del juego actual a la nueva ubicación
            Files.copy(Paths.get(rutaArchivoJuego), Paths.get(nuevaRutaArchivo), StandardCopyOption.REPLACE_EXISTING);
            // Actualiza la ruta del archivo para futuros guardados

            rutaArchivoJuego = nuevaRutaArchivo;
        } catch (IOException e) {
            System.err.println("Error al guardar el archivo: " + e.getMessage());
        }
    }


    /**
     * Agrega una notación adicional al último movimiento registrado la promocion.
     * Útil para agregar indicadores de la coronacion u otras notaciones de movimientos especiales.
     *
     * @param notacion La notación adicional para agregar
     */

    public void appendUltimoMovimiento(String notacion) {
        //Lista de movimientos no vacia
        if (!movimiento.isEmpty()) {
            // Obtiene el último movimiento y agrega la notación de promoción
            //recupera el último movimiento en la lista usando movimiento.size() - 1(el último índice).

            String ultimoMovimiento = movimiento.get(movimiento.size() - 1);
            //ultimoMovimiento:El original"e8".
            //notacion:Notación adicional para agregar, por ejemplo, "=Q"(indicando la promoción de un peón a reina).
            //ultimoMovimiento + notacion:Los combina en `""e8=Q" .
            movimiento.set(movimiento.size() - 1, ultimoMovimiento + notacion);
            //Guarda el juego actualizado

            guardarJuego();
        }
    }
    /**
     * Finaliza el juego y registra el resultado final.
     * Los resultados válidos son: "1-0" (ganan las blancas), "0-1" (ganan las negras), "1/2-1/2" (empate)
     *
     * @param resultado El resultado del juego que se registrará
     */

    public void finJuego(String resultado) {
        this.resultadoJuego = resultado;
        encabezado.put("Resultado", resultado);
        guardarJuego();
    }
}