package Controlador;

/**
 * Representa la posicion en el tablero de ajedrez como un objeto.
 */
public class Posicion {
    /**
     * La fila donde (0-7, tambien 0 es la parte superior de la fila)
     */
    private final int fila;

    /**
     * La columna (0-7, donde 0 es la columna mas a la izquierda)
     */
    private final int col;

    /**
     * Construye una nueva posicion y especifica fila y columna.
     *
     * @param fila la fila (0-7)
     * @param col  la columna
     */
    public Posicion(int fila, int col) {
        this.fila = fila;
        this.col = col;
    }

    /**
     * @return la fila de la posicion
     */
    public int getFila() {
        return fila;
    }

    /**
     * @return La columna de la poscion
     */
    public int getCol() {
        return col;
    }

    @Override
    public boolean equals(Object o) {
        // Verifica si las dos referencias (`this` y `o`) apuntan al mismo objeto en memoria. -
        if (this == o) return true;
        // verifica dos cosas: 1. **`o == null`**: Si el otro objeto (`o`) es `null`, no puede ser igual
        //* al objeto actual, por lo que el método devuelve `false`
        if (o == null || getClass() != o.getClass()) return false;
        Posicion posicion = (Posicion) o;
        return fila == posicion.fila && col == posicion.col;
    }

    /**
     * Genera Hash code para la posicion.
     * la implementacion asegura que las posiciones con las misma cordenadas  tengan el mismo hashcode,
     * La formula aes: 31 * fila + col para crear un hash code unico para cada posicion.
     *
     * @return retorna un hash code con el valor de la posicion
     */

    @Override
    // El uso de un número primo como `31` ayuda a garantizar que el resultado del cálculo del código
    // hash se distribuya de manera más uniforme entre los valores posibles, lo que mejora el rendimiento de las colecciones basadas en hash.
    //a multiplicación garantiza que la fila (`fila`) tenga un mayor impacto en el código hash resultante que la
    // columna (`col`). Esto se debe a que la fila (que generalmente tiene un valor numérico mayor) debería
    // contribuir más a la unicidad del código hash. Por ejemplo, supongamos: - `fila = 2` (3.ª fila) - `col = 5`
    // (6.ª columna) El código hash resultante será: ```java 31 * 2 + 5 = 62 + 5 = 67 ``` Si tiene otra posición,
    // digamos: - `fila = 1` (2.ª fila) - `col = 5` (6.ª columna) El código hash resultante será: ```java 31 * 1 +
    // 5 = 31 + 5 = 36 ``` Como puede ver, la fila (`fila`) tiene un impacto significativo en el valor del código
    // hash debido a la multiplicación por `31`. 4. **¿Por qué utilizar esta fórmula?** - Esta fórmula combina los
    // valores de la fila (`fila`) y la columna (`col`) en un único código hash entero. - La multiplicación por `31`
    // ayuda a garantizar que pequeños cambios en los valores de las filas y columnas resulten en códigos hash
    // significativamente diferentes. Esto reduce el riesgo de colisiones, donde dos posiciones distintas en el
    // tablero de ajedrez podrían terminar con el mismo código hash.
    public int hashCode() {
        return 31 * fila + col;
    }

    /**
     * Retorna un string que representa la posicion
     * El formato es Posicion(fila,col)
     *
     * @return Retorna un string que representa la posicion
     */

    @Override
    public String toString() {
        return "Position(" + fila + "," + col + ")";
    }
}