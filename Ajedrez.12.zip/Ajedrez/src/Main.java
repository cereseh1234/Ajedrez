import Controlador.ControladorAjedrez;
import Controlador.HandlerPGNTiempoReal;
import Modelo.ModeloTableroAjedrez;
import Modelo.ModeloTableroAjedrezImpl;
import Vista.VisorTableroAjedrez;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

public class Main {
    private ModeloTableroAjedrez modelo;
    private VisorTableroAjedrez vista;
    private ControladorAjedrez controlador;
    private JFileChooser chooserArchivo;
    private HandlerPGNTiempoReal pgnHandler;
    private String guardarArchivoTemporal;

    public Main() {
        // Inicializa los componentes MVC

        modelo = new ModeloTableroAjedrezImpl();
        vista = new VisorTableroAjedrez(modelo);

        // Crea un cuadro de diálogo de configuración del juego
        Map<String, String> infojuego = mostrarJuegoPerdido();

        // Crea  un nombre de archivo de guardado temporal con marca de tiempo

        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"));
        guardarArchivoTemporal = "temp_game_" + timestamp + ".pgn";

        // Inicializa el controlador PGN con información del juego

        pgnHandler = new HandlerPGNTiempoReal(
                modelo,
                guardarArchivoTemporal,
                infojuego.get("evento"),
                infojuego.get("sitio"),
                infojuego.get("jugadorBlanco"),
                infojuego.get("jugadorNegro"),
                infojuego.get("eloBlanco"),
                infojuego.get("eloNegro"),
                infojuego.get("round")
        );

        // Inicializa el controlador con el identificador PGN
        controlador = new ControladorAjedrez(modelo, vista, pgnHandler);
        vista.setControlador(controlador);

        // Establece la posición inicial del tablero de ajedrez

        controlador.setupPosicionInicial();


        // Crear un selector de archivos para archivos PGN

        chooserArchivo = new JFileChooser();
        chooserArchivo.setFileFilter(new javax.swing.filechooser.FileFilter() {
            public boolean accept(File f) {
                return f.getName().toLowerCase().endsWith(".pgn") || f.isDirectory();
            }
            public String getDescription() {
                return "archivo PGN (*.pgn)";
            }
        });

        // Crea la ventana principal de la aplicación

        JFrame frame = new JFrame("Ajedrez");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Crea los paneles

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(vista, BorderLayout.CENTER);

        //Crea un panel de control

        JPanel controlPanel = new JPanel(new BorderLayout());
        JPanel botonPanel = new JPanel();

        JButton finalizarBoton = new JButton("Finalizar");
        JButton guardarBoton = new JButton("Guardar");
        JButton cerrarBoton = new JButton("Cerrar");

        // Agrega acciones de botón

        finalizarBoton.addActionListener(e -> mostrarConfirmicionJuego());
        guardarBoton.addActionListener(e -> guardarJuegoComo());
        cerrarBoton.addActionListener(e -> {
            int eleguir = JOptionPane.showConfirmDialog(null, "Confirmas que quieres cerrar:(?", ":(", JOptionPane.YES_NO_OPTION);
            if (eleguir == JOptionPane.YES_OPTION) {
                frame.dispose();
            }
        });

        //Añade botones al panel de control

        botonPanel.add(finalizarBoton);
        botonPanel.add(guardarBoton);
        botonPanel.add(cerrarBoton);
        controlPanel.add(botonPanel, BorderLayout.NORTH);

        // Agrega etiqueta de estado del juego

        JLabel etiquetaEstatus = new JLabel(" Autoguardando");
        controlPanel.add(etiquetaEstatus, BorderLayout.SOUTH);

        //Añade paneles al marco

        mainPanel.add(controlPanel, BorderLayout.SOUTH);
        frame.add(mainPanel);

        // Tamaño y visualización de la ventana
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    /**
     * muestra un cuadro de diálogo de confirmación para el final de una partida de ajedrez,
     * lo que permite a los jugadores seleccionar el resultado de la partida
     */

    private void mostrarConfirmicionJuego() {
        //opciones para representar los posibles resultados del juego:

        Object[] opciones = {"1-0 (Blanco ganaa!)", "0-1 (Negro ganaa !)", "1/2-1/2 (Empate)", "Cancelar"};
        int eleguir = JOptionPane.showOptionDialog(null,
                //El método crea un cuadro de diálogo

                "Selecciona el resultado:",
                "Juego Terminado",
                JOptionPane.YES_NO_CANCEL_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                opciones,
                opciones[3]);
        //Procesa selecciones válidas actualizando el estado del juego y guardando los resultados


        if (eleguir >= 0 && eleguir < 3) {
            String resultado = (String) opciones[eleguir];
            pgnHandler.finJuego(resultado);
            guardarJuegoComo();
        }
    }
    /**
     * define un método que facilita el guardado de una partida de ajedrez en formato PGN
     * Este método utiliza la biblioteca Swing de Java para presentar un cuadro de diálogo
     * de selección de archivos, que permite a los usuarios especificar la ubicación
     * y el nombre del archivo en el que guardar la partida
     */

    private void guardarJuegoComo() {
        chooserArchivo.setDialogTitle("Guardar Archivo PGN");
        //Define nombre de archivo predeterminado

        String nombrePorDefecto = String.format("%s_vs_%s_%s.pgn",
                pgnHandler.getEncabezado("White"),
                pgnHandler.getEncabezado("Black"),
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        // Esta línea establece la selección de archivo inicial
        // en el selector de archivos en el nombre de archivo
        chooserArchivo.setSelectedFile(new File(nombrePorDefecto));
        //Muestra un  cuadro de diálogo Guardar:



        int returnVal = chooserArchivo.showSaveDialog(null);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            File file = chooserArchivo.getSelectedFile();
            // Comprueba si el nombre del archivo termina con ".pgn". En caso contrario, añade ".pgn"

            if (!file.getName().toLowerCase().endsWith(".pgn")) {
                file = new File(file.getAbsolutePath() + ".pgn");
            }
            //Finalmente, muestra un mensaje de confirmación mediante
            // , informa al usuario que el juego se guardó

            pgnHandler.guardarArchivoComo(file.getAbsolutePath());
            JOptionPane.showMessageDialog(null,
                    "Juego guardado en: " + file.getName(),
                    "Guardado Exitosamente",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }

    /**
     *muestra un cuadro de diálogo para configurar una partida de ajedrez, lo que
     * permite a los usuarios ingresar diversos datos, como el nombre del evento, el sitio,
     * el número de ronda, los nombres de los jugadores y sus puntuaciones Elo.
     * @return
     */

    private Map<String, String> mostrarJuegoPerdido() {
        Map<String, String> infoJuego = new HashMap<>();
        //Crea campos de entrada:


        JTextField campoEvento = new JTextField("Ajedrez");
        JTextField campoSitio = new JTextField("Munich");
        JTextField campoRound = new JTextField("1");
        JTextField campojugadorBlanco = new JTextField("Jose");
        JTextField campoJugadorNegro = new JTextField("Lili");
        JTextField campoEloBlanco = new JTextField("2500");
        JTextField campoEloNegro = new JTextField("2600");
        //Prepara mensaje de diálogo

        Object[] message = {
                "Evento:", campoEvento,
                "Sitio:", campoSitio,
                "Round:", campoRound,
                "Jugador Blanco:", campojugadorBlanco,
                "Elo Jugador Blanco:", campoEloBlanco,
                "Jugador Negro:", campoJugadorNegro,
                "Elo Jugador Negro:", campoEloNegro
        };

        int opcion = JOptionPane.showConfirmDialog(null, message, "Game Setup",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (opcion == JOptionPane.OK_OPTION) {
            // Valida campos de entrada

            String nombreEvento = campoEvento.getText().trim();
            String nombreSitio = campoSitio.getText().trim();
            String roundStr = campoRound.getText().trim();
            String jugadorBlanco = campojugadorBlanco.getText().trim();
            String jugadorNegro = campoJugadorNegro.getText().trim();
            String eloBlanco = campoEloBlanco.getText().trim();
            String eloNegro = campoEloNegro.getText().trim();

            // Verifica si la entrada es válida
            if (nombreEvento.matches("^[a-zA-Z]+$")
                    && nombreSitio.matches("^[a-zA-Z]+$")
                    && jugadorBlanco.matches("^[a-zA-Z]+$")
                    && jugadorNegro.matches("^[a-zA-Z]+$")
                    && verificarEntero(eloBlanco)
                    && verificarEntero(eloNegro)
                    && verificarEntero(roundStr)) {
                infoJuego.put("evento", nombreEvento);
                infoJuego.put("sitio", nombreSitio);
                infoJuego.put("round", roundStr);
                infoJuego.put("jugadorBlanco", jugadorBlanco);
                infoJuego.put("jugadorNegro", jugadorNegro);
                infoJuego.put("eloBlanco", eloBlanco);
                infoJuego.put("eloNegro", eloNegro);
            } else {
                JOptionPane.showMessageDialog(null,
                        "Algun campo tiene un caracter que no es aceptado por el mismo.",
                        "Entrada Invalida",
                        JOptionPane.ERROR_MESSAGE);
                return mostrarJuegoPerdido();  // Llamada recursiva para mostrar el diálogo nuevamente

            }
        } else {
            // El usuario canceló el diálogo, usa valores
            infoJuego.put("evento", "Ajedres");
            infoJuego.put("sitio", "Munich");
            infoJuego.put("round", "1");
            infoJuego.put("jugadorBlanco", "Jose");
            infoJuego.put("jugadorNegro", "Lili");
            infoJuego.put("eloBlanco", "2500");
            infoJuego.put("eloNegro", "2600");
        }

        return infoJuego;
    }


    /**
     * comprueba si una cadena determinada se puede convertir en un entero
     * @param str la cadena de entrada
     * @return si el análisis es exitoso el método devuelve true
     * Si no se puede analizar la cadena  el método devuelve false
     */

    private boolean verificarEntero(String str) {
        try {
            Integer.parseInt(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(
                        UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            new Main();
        });
    }
}