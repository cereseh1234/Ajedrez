package Modelo;

/**. Esta clase sirve como representación concreta de una pieza de ajedrez, encapsulando sus atributos y
 *  proporcionando implementaciones para los métodos definidos en la interfaz.
 */
public class BasicPiezaAjedrez implements piezaAjedrez {
    private char simbolo;
    private String color;
    private String tipo;

    /**
     * proporciona implementaciones
     * @param simbolo Un carácter que representa el símbolo visual de la pieza de ajedrez (por ejemplo, 'K'
     * para Rey, 'Q' para Dama).
     * @param color Una cadena que indica el color de la pieza de ajedrez
     * @param tipo Una cadena que representa el tipo de pieza de ajedrez
     */
    public BasicPiezaAjedrez(char simbolo, String color, String tipo) {
        this.simbolo = simbolo;
        this.color = color;
        this.tipo = tipo;
        this.simbolo = getSimboloUnicode(tipo, color);
    }

    private char getSimboloUnicode(String tipo, String color) {
        boolean isWhite = color.equalsIgnoreCase("white");

        return switch (tipo.toLowerCase()) {
            case "king" -> isWhite ? '♔' : '♚';
            case "queen" -> isWhite ? '♕' : '♛';
            case "rook" -> isWhite ? '♖' : '♜';
            case "bishop" -> isWhite ? '♗' : '♝';
            case "knight" -> isWhite ? '♘' : '♞';
            case "pawn" -> isWhite ? '♙' : '♟';
            default -> throw new IllegalArgumentException("Tipo de pieza no soportado: " + tipo);
        };
    }

    /**
     * @return Devuelve el símbolo de la pieza de ajedrez.
     */
    @Override
    public char getSimbolo() { return simbolo; }

    /**
     * @return Devuelve el color de la pieza de ajedrez.
     */
    @Override
    public String getColor() { return color; }

    /**
     * @return Devuelve el tipo de la pieza de ajedrez
     */
    @Override
    public String getTipo() { return tipo; }

    /**
     *El símbolo se muestra junto con su representación Unicode (por ejemplo, para un rey negro).\u265A
     * @return cadena de la pieza de ajedrez,
     */
    @Override
    public String toString() {
        return String.format("ChessPiece[type=%s, color=%s, symbol=%c(\\u%04X)]",
                tipo, color, simbolo, (int) simbolo);
    }
}