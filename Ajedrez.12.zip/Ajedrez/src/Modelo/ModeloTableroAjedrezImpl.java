package Modelo;

import Controlador.Posicion;
import java.util.HashMap;
import java.util.Map;

/**
 * Representa el tablero de ajedrez ademas administra los lugares y movimienots de las piezas usando HasMap
 *Alamcena la relacion entre las posiciones y piezas.
 * Las coordenadas van desde (0,0) a (7,7).
 */
public class ModeloTableroAjedrezImpl implements ModeloTableroAjedrez {
    /**
     * Map Almacena el estado actual del tablero .
     * Key: Posicion objeto que represneta  un cuadro
     * Value: Representa un pieza en la posicion X
     */
    private Map<Posicion, piezaAjedrez> tablero;

    /**
     * Hace un tablero vacio
     * Inizilaiza un HashMao que almacena las piezas.
     */
    public ModeloTableroAjedrezImpl() {
        tablero = new HashMap<>();
    }

    /**
     * Piezas de ajedrez en una poscion especifica del tablero
     * Si ya existe en esa posicion,sera reemplazada
     *
     * @param pos La posicion donde la pieza sera reemplazada
     * @param pieza La pieza
     */
    @Override
    public void lugarPieza(Posicion pos, piezaAjedrez pieza) {
        if (posicionValida(pos)) {
            tablero.put(pos, pieza);
        }
    }

    /**
     * Getter de la pieza
     *
     * @param pos Posicion
     * @return la posicion de la pieza
     */
    @Override
    public piezaAjedrez getPieza(Posicion pos) {
        return tablero.get(pos);
    }

    /**
     * Elimina la pieza de X posicion
     *
     * @param pos La posicion de la pieza
     */
    @Override
    public void removerPieza(Posicion pos) {
        tablero.remove(pos);
    }

    /**
     * Remueva todas las piezas del tablero
     */
    @Override
    public void limpiar() {
        tablero.clear();
    }

    /**
     * Mueve la pieza
     * Si la posicion esta vacia, es invalido.
     *
     * @param from posicion desde donde se movera
     * @param to destino de la pieza
     * @return true si el movimiento es exitoso
     */
    @Override
    public boolean moverPieza(Posicion from, Posicion to) {
        piezaAjedrez pieza = getPieza(from);
        if (pieza != null && posicionValida(to)) {
            //Remueve la pieza de la posicion original
            removerPieza(from);
            //Nueva posicion
            lugarPieza(to, pieza);
            return true;
        }
        return false;
    }

    /**
     *Revisa si la posicion es valida
     * @param pos Posicion a valida
     * @return true si la posicion es valida
     */
    private boolean posicionValida(Posicion pos) {
        return pos.getFila() >= 0 && pos.getFila() < 8 &&
                pos.getCol() >= 0 && pos.getCol() < 8;
    }
}