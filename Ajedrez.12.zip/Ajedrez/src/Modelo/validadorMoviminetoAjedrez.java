package Modelo;

import Controlador.Posicion;

import java.util.ArrayList;
import java.util.List;

public class validadorMoviminetoAjedrez {
    private ModeloTableroAjedrez tablero;
    private int turnoContador;  // Realiza un seguimiento del turno actual



    public validadorMoviminetoAjedrez(ModeloTableroAjedrez tablero) {
        this.tablero = tablero;
        this.turnoContador = 1;// Comienza con el turno 1 (Blanco)
    }

    /**
     * valida si el rey puede moverse de una posición a otra en un tablero de ajedrez
     *
     * @param from La posición inicial del rey.
     * @param to  La posición objetivo a la que el rey  pretende moverse
     * @return true: Si el movimiento de la  reina  es válido
     * * false: si el movimiento no es valido
     * */
    private boolean movimientoValidoRey(Posicion from, Posicion to) {
        //Aquí se calculan las diferencias absolutas entre las filas y columnas de las posiciones from y to.
        // Esto permite determinar cuántas filas y columnas se está moviendo el rey.
        //filaDiff representa la diferencia en filas.
        //colDiff representa la diferencia en columnas.
        int filaDiff = Math.abs(to.getFila() - from.getFila());
        int colDiff = Math.abs(to.getCol() - from.getCol());
        //El rey puede moverse una casilla en cualquier dirección (horizontal, vertical o diagonal), o sea que
        //La diferencia en filas (filaDiff) es menor o igual a 1.
        //Y la diferencia en columnas (colDiff) también es menor o igual a 1.
        //Si ambas condiciones son verdaderas, el método retorna true, indicando que el movimiento del rey es
        // válido. Si alguna de las condiciones no se cumple, retorna false
        return filaDiff <= 1 && colDiff <= 1;
    }

    /**
     * Comprueba si el camino entre dos posiciones en un tablero de ajedrez está bloqueado por otras piezas
     * @param from La posición inicial desde la que se mueve la pieza.
     * @param to La posición objetivo a la que la pieza pretende moverse.
     * @return Si el bucle se completa sin encontrar ninguna pieza que bloquee el camino, devuelve
     * , indicando que el camino está libre.false
     */


    /**
     * valida si el caballo puede moverse de una posición a otra en un tablero de ajedrez
     *
     * @param from La posición inicial del caballo.
     * @param to   :La posición objetivo a la que el caballo pretende moverse.
     * @return true: Si el movimiento del caballo  es válido
     * false: Si el movimiento no es válido
     */


    private boolean movimientoCaballoValido(Posicion from, Posicion to) {
        //Diferencias absolutas para saber cuanto se mueve
        int filaDiff = Math.abs(to.getFila() - from.getFila());
        int colDiff = Math.abs(to.getCol() - from.getCol());
        //Dos filas y una columna: (filaDiff == 2 && colDiff == 1) //Direccion y perpendicularidad
        //Una fila y dos columnas: (filaDiff == 1 && colDiff == 2)
        //Si cualquiera de estas condiciones es verdadera, el método retorna true, indicando que el movimiento del
        // caballo es válido. Si no, retorna false.
        return (filaDiff == 2 && colDiff == 1) || (filaDiff == 1 && colDiff == 2);
    }



    private boolean caminoBloqueado(Posicion from, Posicion to) {
        //Aquí se utilizan los métodos Integer.compare() para calcular los pasos necesarios para mover desde la
        // posición from a la posición to:
        //filaStep será 1, 0, o -1 dependiendo de si la fila de to es mayor, igual o menor que la fila de FROM,
        // respectivamente, ejemplo
        //from=10 to=20
        //10<20 la SALIDA es -1
        //colStep funcionará de manera similar para las columnas.
        //Esto permite determinar la dirección del movimiento (hacia arriba, hacia abajo, hacia la derecha o
        // hacia la izquierda).
        int filaStep = Integer.compare(to.getFila(), from.getFila());
        int colStep = Integer.compare(to.getCol(), from.getCol());
        //Se inicializa una nueva posición llamada actual, que representa la siguiente casilla en la dirección
        // del movimiento. Comienza justo después de la posición inicial (from).

        Posicion actual = new Posicion(from.getFila() + filaStep, from.getCol() + colStep);
        //El bucle continúa mientras la posición actual no sea igual a la posición de destino (to).
        //Se verifica si hay una pieza en la posición actual utilizando tablero.getPieza(actual).
        // Si hay una pieza (!= null), se retorna true, indicando que el camino está bloqueado.
        //Si no hay una pieza, se actualiza la posición actual para avanzar hacia la posición de destino,
        // sumando los pasos calculados (filaStep y colStep).
        while (!actual.equals(to)) {
            if (tablero.getPieza(actual) != null) return true;
            actual = new Posicion(actual.getFila() + filaStep, actual.getCol() + colStep);
        }
        //Si el bucle termina sin encontrar ninguna pieza bloqueando el camino, se retorna false,
        // indicando que el camino está libre.
        return false;
    }


    /**
     * valida si el alfil puede moverse de una posición a otra en un tablero de ajedrez
     *
     * @param from La posición inicial del alfil.
     * @param to   La posición objetivo a la que el alfil pretende moverse
     * @return true: Si el movimiento del alfil  es válido
     * false: Si el movimiento no es válido
     */


    private boolean movimientoValidoAlfil(Posicion from, Posicion to) {
        //El alfil se mueve en línea diagonal, lo que significa que la diferencia en filas
        // debe ser igual a la diferencia en columnas. Esta línea utiliza Math.abs() para calcular las diferencias
        // absolutas entre las filas y columnas de las posiciones from y to.
        //Si la diferencia en filas no es igual a la diferencia en columnas, retorna false, indicando que el
        // movimiento no es válido.
        if (Math.abs(to.getFila() - from.getFila()) != Math.abs(to.getCol() - from.getCol())) return false;
        //Si el camino no está bloqueado, caminoBloqueado retornará false, y al negarlo se retornará true.
        return !caminoBloqueado(from, to);
    }

    /**
     * valida si una torre puede moverse de una posición a otra en un tablero de ajedrez
     *
     * @param from La posición inicial de la torre.
     * @param to   :La posición objetivo a la que la torre pretende moverse.
     * @return true: Si el movimiento de la torre es válido
     * false: Si el movimiento no es válido
     */

    private boolean movimientoTorreValido(Posicion from, Posicion to) {
        //La torre se mueve en línea recta (mismo número de fila) o verticalmente (mismo número de columna).
        // Esta línea comprueba si las posiciones inicial y final no están en la misma fila ni en la misma columna.
        // Si ambas condiciones son verdaderas,
        // retorna false, indicando que el movimiento no es válido.
        if (from.getFila() != to.getFila() && from.getCol() != to.getCol()) return false;
        //Si el camino no está bloqueado, caminoBloqueado retornará false, y al negarlo se retornará true,
        // indicando que el movimiento es válido.
        return !caminoBloqueado(from, to);
    }


    /**
     * valida si la dama puede moverse de una posición a otra en un tablero de ajedrez
     *
     * @param from La posición inicial de la reina.
     * @param to   La posición objetivo a la que la reina pretende moverse
     * @return true: Si el movimiento de la  reina  es válido
     * false: Si el movimiento no es válido
     */


    private boolean movimientoValidoDama(Posicion from, Posicion to) {
        return movimientoTorreValido(from, to) || movimientoValidoAlfil(from, to);
    }



    /**
     * Verifica si un movimiento de peón es válido según las reglas del ajedrez
     * @param from Posición inicial del peón
     * @param to Posición destino del peón
     * @param color Color del peón ("white" o "black")
     * @return true si el movimiento es válido, false en caso contrario
     */
    private boolean movimientoValidoPeon(Posicion from, Posicion to, String color) {
        // Determina la dirección del movimiento según el color
        // Blancas mueven hacia arriba (-1) y negras hacia abajo (+1)
        int direccion = color.equals("white") ? -1 : 1;

        // Calcula la diferencia de filas y columnas entre la posición inicial y final
        int filaDiff = to.getFila() - from.getFila();
        int colDiff = Math.abs(to.getCol() - from.getCol());

        // Verifica movimiento básico hacia adelante:
        // - Sin cambio de columna (colDiff == 0)
        // - Avanza una casilla en la dirección correcta (filaDiff == direccion)
        // - La casilla destino debe estar vacía
        if (colDiff == 0 && filaDiff == direccion && tablero.getPieza(to) == null) {
            return true;
        }

        // Verifica el movimiento inicial de dos casillas:
        // - Sin cambio de columna (colDiff == 0)
        // - Para blancas: desde fila 6 moviendo dos casillas hacia arriba
        // - Para negras: desde fila 1 moviendo dos casillas hacia abajo
        // - Tanto la casilla intermedia como la final deben estar vacías
        if (colDiff == 0 && ((color.equals("white") && from.getFila() == 6 && filaDiff == -2) ||
                (color.equals("black") && from.getFila() == 1 && filaDiff == 2))) {
            Posicion intermedia = new Posicion(from.getFila() + direccion, from.getCol());
            return tablero.getPieza(intermedia) == null && tablero.getPieza(to) == null;
        }

        // Verifica movimiento de captura:
        // - Debe moverse una columna en diagonal (colDiff == 1)
        // - Debe avanzar una fila en la dirección correcta (filaDiff == direccion)
        // - La casilla destino debe contener una pieza del color opuesto
        if (colDiff == 1 && filaDiff == direccion) {
            piezaAjedrez piezaObjetivo = tablero.getPieza(to);
            return piezaObjetivo != null && !piezaObjetivo.getColor().toLowerCase().equals(color);
        }

        // Si ninguna de las condiciones anteriores se cumple, el movimiento es inválido
        return false;
    }

    /**
     * Método para obtener el turno actual en función del contador de turnos
     *
     * @return el color de jugador apropiado en función del resultado de la condición.
     * Si la condición es verdadera, el método devuelve "blanco".
     * De lo contrario, devuelve "negro".
     */

    public String getTurnoActual() {
        //La expresión turnoContador % 2 == 1 verifica si el contador de turnos actual
// es un número impar. Esto se debe a que queremos asignar al jugador "blanco"
// los turnos impares y al jugador "negro" los turnos pares.

        return (turnoContador % 2 == 1) ? "white" : "black";
    }
    //Aqui
    public boolean MovimientoValidos(Posicion from, Posicion to) {
        piezaAjedrez pieza = tablero.getPieza(from);
        if (pieza == null) return false;// Si no hay ninguna pieza en la posición 'from', el movimiento no es válido




        // Se obtiene el color del jugador cuyo turno es actual (turnoActual) y se compara con el color de
        // la pieza. Si los colores no coinciden, se imprime un mensaje indicando que es el turno equivocado y
        // se retorna false.

        String turnoActual = getTurnoActual();
        String piezaColor = pieza.getColor().toLowerCase();

        if (!piezaColor.equals(turnoActual)) {
            System.out.println("Turno equivocado! Turno actual: " + turnoActual + ", Color Pieza: " + piezaColor);
            return false;
        }

       //Se verifica si hay una pieza en la posición de destino (to). Si hay una pieza y su color coincide
        // con el color de la pieza que se está moviendo, se retorna false, ya que no se puede capturar
        // una propia pieza.

        piezaAjedrez targetPieza = tablero.getPieza(to);
        if (targetPieza != null && targetPieza.getColor().toLowerCase().equals(piezaColor)) {
            return false;
        }
//Aquí se utiliza una expresión switch para determinar el tipo de la pieza y llamar al método
// correspondiente que valida el movimiento para ese tipo. Cada caso llama a un método específico que
//      implementa las reglas de movimiento para peones, torres, caballos, alfiles, reinas y reyes
        String tipoPieza = pieza.getTipo().toLowerCase();
        boolean movimientoValidoPieza = switch (tipoPieza) {
            case "pawn" -> movimientoValidoPeon(from, to, piezaColor);
            case "rook" -> movimientoTorreValido(from, to);
            case "knight" -> movimientoCaballoValido(from, to);
            case "bishop" -> movimientoValidoAlfil(from, to);
            case "queen" -> movimientoValidoDama(from, to);
            case "king" -> movimientoValidoRey(from, to);
            default -> false;
        };

        return movimientoValidoPieza;
    }


    /**
     * // Método para cambiar de turno
     */

    public void cambiarTurno() {
        turnoContador++;
        System.out.println("Turn " + turnoContador + ": " + getTurnoActual() + " turno");
    }

    /** * Getter para el contador de turnos *
     * * @return devuelve el valor actual de la variable Contador de turnos. */

    public int getContadorTurno() {
        return turnoContador;
    }

    /**
     * Ubica la posición del rey de un color determinado en el tablero de ajedrez.
     *
     * @param color el color del rey a buscar ("blanco" o "negro").
     * @return la posición del rey si se encuentra; de lo contrario, nulo.
     */

    //Aqui
    private Posicion encontrarRey(String color) {
        //Se utilizan dos bucles anidados para recorrer todas las posiciones del tablero de ajedrez,
        // que tiene un tamaño de 8x8. La variable fila representa la fila actual (de 0 a 7) y
        // col representa la columna actual (también de 0 a 7).
        for (int fila = 0; fila < 8; fila++) {
            for (int col = 0; col < 8; col++) {
                Posicion pos = new Posicion(fila, col);// Crea
                piezaAjedrez pieza = tablero.getPieza(pos);//Obtiene pieza si no null
                //Aquí se verifica si hay una pieza en la posición actual (pieza != null) y si esa pieza es un
                // rey (pieza.getTipo().toLowerCase().equals("king")). Además, se comprueba si el color de la
                // pieza coincide con el color especificado (pieza.getColor().toLowerCase().equals(color)).
                // Si todas estas condiciones son verdaderas, se retorna la posición del rey
                if (pieza != null &&
                        pieza.getTipo().toLowerCase().equals("king") &&
                        pieza.getColor().toLowerCase().equals(color)) {
                    return pos;
                }
            }
        }
        return null;
    }

    /**
     * Verifica si el rey del jugador especificado está en jaque
     * @param colorJugador El color del jugador ("white" o "black")
     * @return true si el rey está en jaque, false en caso contrario
     */

    public boolean enJake(String colorJugador) {
        // Busca la posición actual del rey del jugador
        Posicion posicionRey = encontrarRey(colorJugador);

        // Si no se encuentra el rey, retorna false (caso que no debería ocurrir en un juego normal)
        if (posicionRey == null) return false;

        // Determina el color del oponente basado en el color del jugador actual
        String colorOponente = colorJugador.equalsIgnoreCase("white") ? "black" : "white";

        // Verifica si la posición del rey está siendo atacada por alguna pieza del oponente
        return cuadroAtacado(posicionRey, colorOponente);
    }

    /**
     * movimientoDeberiaPrevenirJake se utiliza para determinar si un movimiento propuesto evitaría
     * que el rey del jugador quede en jaque.
     *
     * @param from La posición en el tablero donde se encuentra actualmente la pieza.
     * @param to  La posición en el tablero donde se propone mover la pieza.
     * @param colorJugador El color del jugador cuyo movimiento se está evaluando.
     * @return True si el moviemiento previene el jake
     */

    private boolean movimientoDeberiaPrevenirJake(Posicion from, Posicion to, String colorJugador) {
        // Guarda el estado actual del tablero


        piezaAjedrez piezaCapturada = tablero.getPieza(to);

        // Hace el movimiento temporalmente

        tablero.moverPieza(from, to);

        // Comprueba si el rey todavía está en jaque

        boolean todaviaEnJake = enJake(colorJugador);

        // Restaurar el estado del tablero

        tablero.moverPieza(to, from);
        if (piezaCapturada != null) {
            tablero.lugarPieza(to, piezaCapturada);
        }

        // Devuelve verdadero si este movimiento evitaría la verificación

        return !todaviaEnJake;
    }



    /**
     * determinar si una pieza determinada puede atacar una casilla específica del tablero de ajedrez, independientemente del turno del jugador actual. Esto es útil para comprobar si un rey está en jaque,
     * ya que el método debe tener en cuenta todas las piezas del oponente que podrían atacar la casilla del rey.
     * puede atacar el cuadrado especificado por el parámetro 'to', comenzando desde la posición 'from'.
     *
     *@param from La posición en el tablero donde se encuentra actualmente la pieza.
     * @param to  La posición en el tablero donde se propone mover la pieza.
     * @param pieza  La pieza que quiere atacar
     * @return
     */


    private boolean puedePuezaAtacarXCuadro(Posicion from, Posicion to, piezaAjedrez pieza) {
        String tipoPieza = pieza.getTipo().toLowerCase();

        // Utilice la lógica de validación de movimientos existente pero ignore el orden de turno

        switch (tipoPieza) {
            case "pawn":
                return movimientoValidoPeon(from, to, pieza.getColor().toLowerCase());
            case "rook":
                return movimientoTorreValido(from, to);
            case "knight":
                return movimientoCaballoValido(from, to);
            case "bishop":
                return movimientoValidoAlfil(from, to);
            case "queen":
                return movimientoValidoDama(from, to);
            case "king":
                return movimientoValidoRey(from, to);
            default:
                return false;
        }
    }


    /**
     *cuadroAtacado es responsable de determinar si una casilla determinada del tablero
     *  de ajedrez está bajo ataque por alguna de las piezas del oponente.
     * @param cuadro La posición en el tablero que queremos comprobar en busca de ataques.
     * @param colorAtacante El color del jugador cuyas piezas queremos comprobar para detectar ataques.
     * @return //Si el método completa el bucle sin encontrar ninguna de las colorPiezaAtacante del jugador
     * que pueda atacar al cuadro, devuelve false, lo que indica que el cuadro no está bajo ataque.
     */
    private boolean cuadroAtacado(Posicion cuadro, String colorAtacante) {
        //Para cada cuadrado, verifica si hay una pieza en ese cuadrado y si la pieza pertenece al jugadorcolorAtacante.



        for (int fila = 0; fila < 8; fila++) {
            for (int col = 0; col < 8; col++) {
                Posicion from = new Posicion(fila, col);
                piezaAjedrez pieza = tablero.getPieza(from);
//Si se encuentra una pieza que pertenece al jugadorColorAtacnate, el método llama al  puedePuezaAtacarXCuadro()
//método para verificar si esa pieza puede atacar la casilla se pasó como parámetro.
                if (pieza != null &&
                        pieza.getColor().equalsIgnoreCase(colorAtacante) &&
                       // true, lo que indica que el cuadrado está bajo ataque.
                        puedePuezaAtacarXCuadro(from, cuadro, pieza)) {
                    return true;
                }
            }
        }
        return false;
    }




    /**
     * Obtiene una lista de todas las posiciones que contienen piezas de un color específico
     * Recorre todo el tablero buscando piezas del color indicado
     * @param color Color de las piezas a buscar
     * @return Lista de posiciones donde se encuentran las piezas del color especificado
     */
    private List<Posicion> obtenerPosicionesPiezas(String color) {
        // Declara una lista que almacenará las posiciones encontradas
        List<Posicion> posiciones = new ArrayList<>();

// Recorre cada casilla del tablero de 8x8
        for (int fila = 0; fila < 8; fila++) {
            for (int col = 0; col < 8; col++) {
                // Crea un objeto Posicion para la casilla actual
                Posicion pos = new Posicion(fila, col);

                // Obtiene la pieza en esa posición del tablero
                piezaAjedrez pieza = tablero.getPieza(pos);

                // Verifica si hay una pieza y si es del color buscado
                if (pieza != null && pieza.getColor().equalsIgnoreCase(color)) {
                    // Añade la posición a la lista si cumple las condiciones
                    posiciones.add(pos);
                }
            }
        }

// Devuelve la lista completa de posiciones encontradas
        return posiciones;
    }
    /**
     * Prueba un movimiento temporalmente para verificar si deja al rey en jaque
     * Realiza el movimiento, verifica el jaque y deshace el movimiento
     * @param from Posición inicial de la pieza
     * @param to Posición destino de la pieza
     * @param jugadorColor Color del jugador que realiza el movimiento
     * @return true si el movimiento no deja al rey en jaque
     */
    //Este método privado se encarga de probar si un movimiento específico es seguro para el rey del jugador.
    // Devuelve un valor booleano que indica si el movimiento es válido (es decir, si no deja al rey en jaque).
    private boolean probarMovimientoRey(Posicion from, Posicion to, String jugadorColor) {
      //  Aquí se guarda la pieza que podría estar en la posición de destino (to).
        //  Esto es importante para restaurar el estado del tablero después de probar el movimiento.
        piezaAjedrez piezaCapturada = tablero.getPieza(to);

        // Realiza el movimiento temporalmente
        tablero.moverPieza(from, to);

        // Verifica si después del movimiento el rey sigue en jaque
        boolean todaviaEnJake = enJake(jugadorColor);

        // Deshace el movimiento temporal
        tablero.moverPieza(to, from);

        // Si había una pieza en el destino, la restaura
        if (piezaCapturada != null) {
            tablero.lugarPieza(to, piezaCapturada);
        }

        // Retorna true si el movimiento saca del jaque, false si no
        return !todaviaEnJake;
    }
    //Aqui
    /**
     * Verifica si un movimiento específico es válido
     * Combina la validación de reglas básicas con la verificación de jaque
     * @param from Posición inicial de la pieza
     * @param to Posición destino de la pieza
     * @param jugadorColor Color del jugador que realiza el movimiento
     * @return true si el movimiento es válido y no deja al rey en jaque
     */
    private boolean esMovimientoValido(Posicion from, Posicion to, String jugadorColor) {
        //Primero, se verifica si el movimiento entre las posiciones from y to es válido según las
        // reglas básicas del juego mediante el método MovimientoValidos(from, to). Si no es válido,
        //  retorna false.
        if (!MovimientoValidos(from, to)) {
            return false;
        }
        //Si el movimiento es válido según las reglas básicas, se llama al método
        // probarMovimientoRey(from, to, jugadorColor) para comprobar si este movimiento dejaría al rey en jaque
        return probarMovimientoRey(from, to, jugadorColor);
        //Retorna true si ambos chequeos son satisfactorios; de lo contrario, retorna false
    }


    //Aqui
    /**
     * Verifica si una pieza en una posición específica tiene movimientos válidos disponibles
     * Examina todas las posibles casillas destino del tablero
     * @param from Posición de la pieza a verificar
     * @param jugadorColor Color del jugador que controla la pieza
     * @return true si la pieza tiene al menos un movimiento válido
     */
    private boolean tienePiezaMovimientosValidos(Posicion from, String jugadorColor) {
        for (int toFila = 0; toFila < 8; toFila++) {
            for (int toCol = 0; toCol < 8; toCol++) {
                Posicion to = new Posicion(toFila, toCol);
                if (esMovimientoValido(from, to, jugadorColor)) {
                    return true;
                }
            }
        }
        return false;
    }


    /**
     * Verifica si existen movimientos legales disponibles para un jugador
     * Recorre todas las piezas del jugador y verifica si alguna tiene movimientos válidos
     * @param jugadorColor Color del jugador a verificar ("white" o "black")
     * @return true si existe al menos un movimiento legal disponible
     */
    private boolean existenMovimientosLegales(String jugadorColor) {
        //Aquí se utiliza un bucle for para iterar sobre cada posición de las piezas del jugador.
        // La función obtenerPosicionesPiezas(jugadorColor) devuelve una colección de objetos Posicion
        // que representan las ubicaciones actuales de todas las piezas del jugador en el tablero.
        for (Posicion from : obtenerPosicionesPiezas(jugadorColor)) {
            //Dentro del bucle, se llama al método tienePiezaMovimientosValidos(from, jugadorColor),
            // que verifica si la pieza en la posición from tiene al menos un movimiento legal disponible.
            // Si este método devuelve true, significa que el jugador tiene al menos una pieza que puede
            //  moverse legalmente, por lo que el método existenMovimientosLegales retorna true.
            if (tienePiezaMovimientosValidos(from, jugadorColor)) {
                return true;
            }
        }
        return false;
    }

    /**
     * jakeMate es responsable
     * de determinar si el jugador actual se encuentra en una situación de jaque mate
     *
     * @return Regresa true si no se encuentran movimientos válidos para sacar al rey del jaque, lo que indica un jaque mate.
     */

    public boolean jakeMate() {
        String jugadorActual = getTurnoActual();

        // devuelve true si el jugador está en jaque y false si no lo está. Si el jugador no está en jaque
        // (!enJake(jugadorActual)), el método retorna false, indicando que no hay jaque mate.

        if (!enJake(jugadorActual)) {
            return false;
        }
        //Si el jugador actual está en jaque, esta línea se ejecuta y llama a..

        return !existenMovimientosLegales(jugadorActual);
    }

    /**
     * Verifica si una pieza pertenece al jugador especificado.
     *
     * @param pieza La pieza de ajedrez a verificar
     * @param jugador El color del jugador
     * @return true si la pieza pertenece al jugador, false en caso contrario
     */
    //1. **Verificar si la pieza no es nula** ```java pieza != null ``` -
    // Esta condición verifica si la `pieza` (piece) no es `null`
    // Si la pieza es `null`, significa que no hay ninguna pieza en la posición dada,
    // y el método devolverá inmediatamente `false`. -
    private boolean esPiezaDelJugador(piezaAjedrez pieza, String jugador) {
        //Compara el color de la pieza con el color del jugador.
        return pieza != null && pieza.getColor().equalsIgnoreCase(jugador);
    }

    /**
     * Obtiene todas las posiciones que contienen piezas del jugador especificado.
     *
     * @param jugador El color del jugador cuyas piezas se buscarán
     * @return Lista de posiciones que contienen las piezas del jugador
     */
    private List<Posicion> obtenerTodasLasPosicionesDePiezas(String jugador) {
        //nicializa una lista vacía posicionespara almacenar
        List<Posicion> posiciones = new ArrayList<>();
        //. Iterar sobre todas las posiciones del tablero
        for (int fila = 0; fila < 8; fila++) {
            for (int columna = 0; columna < 8; columna++) {
                //Para cada combinación de filay `colcolumna, un nuevoPosicionSe crea el objeto y la recupera
                Posicion pos = new Posicion(fila, columna);
                piezaAjedrez pieza = tablero.getPieza(pos);
                //Llamadas esPiezaDelJugador(pieza, jugador)para determinar sijugador):
                //Si la pieza es null(false.
                //Si la pieza es propiedad del jugador ( jugador), devuelve `true, y elposicioneslista
                if (esPiezaDelJugador(pieza, jugador)) {
                    posiciones.add(pos);
                }
            }
        }
        return posiciones;
    }
    /**
     * Verifica si un movimiento es legal y no deja al rey en jaque.
     *
     * @param desde La posición inicial
     * @param hasta La posición de destino
     * @param jugador El color del jugador
     * @return true si el movimiento es legal y seguro, false en caso contrario
     */
    private boolean esMovimientoLegal(Posicion desde, Posicion hasta, String jugador) {
        return MovimientoValidos(desde, hasta) && movimientoDeberiaPrevenirJake(desde, hasta, jugador);
    }
    /**
     * Obtiene todas las posiciones posibles en el tablero.
     *
     * @return Lista de todas las posiciones posibles en el tablero de ajedrez
     */
    private List<Posicion> obtenerTodosLosDestinosPosibles() {
        //Crear una lista vacía de destinos** ```java List<Posicion> destinos = new ArrayList<>(); ```
        // - Se crea una `ArrayList` vacía de objetos `Posicion`. Esta lista eventualmente contendrá todos los
        // destinos posibles en el tablero.
        List<Posicion> destinos = new ArrayList<>();
        for (int fila = 0; fila < 8; fila++) {
            for (int columna = 0; columna < 8; columna++) {
                destinos.add(new Posicion(fila, columna));
            }
        }
        return destinos;
    }

    /**
     * Verifica si hay movimientos legales disponibles desde una posición específica.
     *
     * @param desde La posición inicial a verificar
     * @param jugador El color del jugador
     * @return true si hay al menos un movimiento legal desde esta posición, false en caso contrario
     */
    private boolean tieneMoivimientosLegalesDesdePosicion(Posicion desde, String jugador) {
        // Por ejemplo, podría devolver cada posición en el tablero (por ejemplo, las 64 casillas en ajedrez).
        // - Estos son movimientos potenciales para evaluar, pero no todos serán legales. -
        return obtenerTodosLosDestinosPosibles()
                // Crea un flujo para iterar sobre cada posible destino (`hasta`)
                .stream()
                // - Las reglas de movimiento de la pieza. - Si el destino está ocupado
                // por una pieza aliada. - Si el movimiento pone al jugador en jaque.
                .anyMatch(hasta -> esMovimientoLegal(desde, hasta, jugador));
    }

    /**
     * Verifica si el jugador especificado tiene algún movimiento legal disponible.
     *
     * @param jugador El color del jugador a verificar
     * @return true si el jugador tiene al menos un movimiento legal, false en caso contrario
     */
    private boolean tieneMoivimientosLegales(String jugador) {
        return obtenerTodasLasPosicionesDePiezas(jugador).stream()
                //Comprueba los movimientos legales desde cada posición
                .anyMatch(desde -> tieneMoivimientosLegalesDesdePosicion(desde, jugador));
    }

    /**
     * verifica si el estado actual de la partida es un empate en ajedrez
     * @return Si se han comprobado todos los movimientos posibles y no se encuentra ninguno
     * que permita al jugador realizar un movimiento legal sin poner a su rey en jaque, entonces devuelve
     * , lo que indica un punto muerto.true
     */

    public boolean esAhogado() {
        String jugadorActual = getTurnoActual();

       // Comprueba si el jugador actual está bajo control ( enJake(jugadorActual)).
              //  Si el jugador está en jaque, no puede haber un punto muerto, por lo que el método devuelve
        if (enJake(jugadorActual)) {
            return false;
        }
//Comprueba si el jugador actual tiene movimientos legales disponibles ( tieneMoivimientosLegales(jugadorActual)).
//Si no hay movimientos legales y el jugador no está en jaque , el juego está en punto muerto.
        return !tieneMoivimientosLegales(jugadorActual);
    }





















}